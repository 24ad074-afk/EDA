export interface FeatureSpec {
  name: string;
  label: string;
  category: 'demographic' | 'history' | 'biometric';
  type: 'binary' | 'continuous' | 'ordinal';
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  defaultVal: number;
  description: string;
  options?: { value: number; label: string }[];
}

export const FEATURES_LIST: FeatureSpec[] = [
  {
    name: 'male',
    label: 'Biological Sex',
    category: 'demographic',
    type: 'binary',
    defaultVal: 1,
    description: 'Biological sex at birth (0 = Female, 1 = Male)',
    options: [
      { value: 0, label: 'Female' },
      { value: 1, label: 'Male' }
    ]
  },
  {
    name: 'age',
    label: 'Patient Age',
    category: 'demographic',
    type: 'continuous',
    min: 30,
    max: 80,
    step: 1,
    unit: 'years',
    defaultVal: 52,
    description: 'Chronological age in years (strongest natural non-modifiable predictor)'
  },
  {
    name: 'education',
    label: 'Education Level',
    category: 'demographic',
    type: 'ordinal',
    defaultVal: 2,
    description: 'Educational attainment level (socioeconomic health literacy proxy)',
    options: [
      { value: 1, label: '1: Some High School' },
      { value: 2, label: '2: High School / GED' },
      { value: 3, label: '3: Some College' },
      { value: 4, label: '4: College Degree' }
    ]
  },
  {
    name: 'currentSmoker',
    label: 'Tobacco Smoking Status',
    category: 'demographic',
    type: 'binary',
    defaultVal: 1,
    description: 'Whether the patient actively smokes tobacco cigarettes',
    options: [
      { value: 0, label: 'Non-Smoker' },
      { value: 1, label: 'Active Smoker' }
    ]
  },
  {
    name: 'cigsPerDay',
    label: 'Cigarettes Per Day',
    category: 'demographic',
    type: 'continuous',
    min: 0,
    max: 60,
    step: 1,
    unit: 'cigs/day',
    defaultVal: 15,
    description: 'Daily cigarette consumption (endothelial and arterial plaque accelerator)'
  },
  {
    name: 'BPMeds',
    label: 'Blood Pressure Medication',
    category: 'history',
    type: 'binary',
    defaultVal: 0,
    description: 'Whether patient is actively prescribed anti-hypertensive medication',
    options: [
      { value: 0, label: 'Not on BP Meds' },
      { value: 1, label: 'Prescribed BP Meds' }
    ]
  },
  {
    name: 'prevalentStroke',
    label: 'History of Stroke',
    category: 'history',
    type: 'binary',
    defaultVal: 0,
    description: 'Prior cerebrovascular accident / ischemic stroke',
    options: [
      { value: 0, label: 'No Prior Stroke' },
      { value: 1, label: 'Prior Stroke Event' }
    ]
  },
  {
    name: 'prevalentHyp',
    label: 'Prevalent Hypertension',
    category: 'history',
    type: 'binary',
    defaultVal: 1,
    description: 'Physician-diagnosed chronic arterial hypertension',
    options: [
      { value: 0, label: 'Normotensive' },
      { value: 1, label: 'Hypertensive' }
    ]
  },
  {
    name: 'diabetes',
    label: 'Diagnosed Diabetes',
    category: 'history',
    type: 'binary',
    defaultVal: 0,
    description: 'Clinical diagnosis of Diabetes Mellitus',
    options: [
      { value: 0, label: 'Non-Diabetic' },
      { value: 1, label: 'Diabetic' }
    ]
  },
  {
    name: 'totChol',
    label: 'Total Cholesterol',
    category: 'biometric',
    type: 'continuous',
    min: 110,
    max: 450,
    step: 1,
    unit: 'mg/dL',
    defaultVal: 236,
    description: 'Total serum cholesterol level (atherogenic lipid biomarker)'
  },
  {
    name: 'sysBP',
    label: 'Systolic Blood Pressure',
    category: 'biometric',
    type: 'continuous',
    min: 80,
    max: 230,
    step: 1,
    unit: 'mmHg',
    defaultVal: 135,
    description: 'Peak pressure during cardiac ventricular contraction (Top predictor)'
  },
  {
    name: 'diaBP',
    label: 'Diastolic Blood Pressure',
    category: 'biometric',
    type: 'continuous',
    min: 50,
    max: 130,
    step: 1,
    unit: 'mmHg',
    defaultVal: 84,
    description: 'Minimum arterial pressure during ventricular filling phase'
  },
  {
    name: 'BMI',
    label: 'Body Mass Index (BMI)',
    category: 'biometric',
    type: 'continuous',
    min: 16.0,
    max: 48.0,
    step: 0.1,
    unit: 'kg/m²',
    defaultVal: 26.2,
    description: 'Adiposity metric: weight divided by height squared'
  },
  {
    name: 'heartRate',
    label: 'Resting Heart Rate',
    category: 'biometric',
    type: 'continuous',
    min: 45,
    max: 130,
    step: 1,
    unit: 'bpm',
    defaultVal: 76,
    description: 'Resting cardiac pulse frequency in beats per minute'
  },
  {
    name: 'glucose',
    label: 'Fasting Blood Glucose',
    category: 'biometric',
    type: 'continuous',
    min: 50,
    max: 300,
    step: 1,
    unit: 'mg/dL',
    defaultVal: 85,
    description: 'Fasting plasma glucose level (indicator of metabolic dysregulation)'
  }
];

export const PRESET_PATIENTS = [
  {
    name: 'Healthy Young Adult (Low Risk)',
    description: '36-year-old female non-smoker with optimal blood pressure and lipid panel.',
    values: {
      male: 0, age: 36, education: 4, currentSmoker: 0, cigsPerDay: 0,
      BPMeds: 0, prevalentStroke: 0, prevalentHyp: 0, diabetes: 0,
      totChol: 180, sysBP: 112, diaBP: 74, BMI: 22.4, heartRate: 68, glucose: 78
    }
  },
  {
    name: 'Middle-Aged Active Smoker (Moderate Risk)',
    description: '51-year-old male smoking 20 cigarettes/day with borderline prehypertension.',
    values: {
      male: 1, age: 51, education: 2, currentSmoker: 1, cigsPerDay: 20,
      BPMeds: 0, prevalentStroke: 0, prevalentHyp: 0, diabetes: 0,
      totChol: 242, sysBP: 136, diaBP: 86, BMI: 27.1, heartRate: 78, glucose: 89
    }
  },
  {
    name: 'Hypertensive Diabetic Senior (High Risk)',
    description: '64-year-old male with Stage 2 hypertension, diabetes, and prior vascular history.',
    values: {
      male: 1, age: 64, education: 1, currentSmoker: 1, cigsPerDay: 15,
      BPMeds: 1, prevalentStroke: 0, prevalentHyp: 1, diabetes: 1,
      totChol: 285, sysBP: 178, diaBP: 104, BMI: 32.8, heartRate: 88, glucose: 195
    }
  }
];

export const SCALER_PARAMS = {
  features: ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose'],
  mean: [49.7294, 8.9963, 236.4976, 132.3568, 82.8556, 25.8601, 75.9124, 81.7230],
  scale: [8.6103, 11.9099, 44.1360, 21.8611, 11.8489, 4.1418, 12.1258, 23.4815]
};

export const VERIFIED_METRICS = {
  testSamples: 636,
  testNegatives: 540,
  testPositives: 96,
  defaultThreshold: {
    threshold: 0.50,
    accuracy: 69.03,
    precision: 25.37,
    recall: 54.17,
    f1Score: 0.3455,
    rocAuc: 0.6788,
    confusionMatrix: { tn: 387, fp: 153, fn: 44, tp: 52 }
  },
  clinicalThreshold: {
    threshold: 0.35,
    accuracy: 51.10,
    precision: 20.71,
    recall: 79.17,
    f1Score: 0.3283,
    confusionMatrix: { tn: 249, fp: 291, fn: 20, tp: 76 }
  }
};

export const TUNING_CONFIGS = [
  {
    name: 'Config A (Compact MLP) [CHAMPION]',
    hiddenUnits: '[32, 16]',
    dropout: 0.10,
    learningRate: 0.001,
    stoppedEpoch: 28,
    valLoss: 0.6165,
    valAccuracy: 70.44,
    valRecall: 60.82,
    valAuc: 0.7113,
    champion: true,
    note: 'Selected as Champion model. Optimal generalization without variance inflation on medium-size tabular records.'
  },
  {
    name: 'Config B (Standard Deep MLP)',
    hiddenUnits: '[64, 32]',
    dropout: 0.20,
    learningRate: 0.001,
    stoppedEpoch: 21,
    valLoss: 0.6131,
    valAccuracy: 70.13,
    valRecall: 59.79,
    valAuc: 0.6899,
    champion: false,
    note: 'Slightly lower validation AUC; early stopping triggered early at epoch 21 due to early validation plateau.'
  },
  {
    name: 'Config C (Regularized Deep MLP)',
    hiddenUnits: '[64, 32, 16]',
    dropout: 0.30,
    learningRate: 0.0005,
    stoppedEpoch: 23,
    valLoss: 0.6524,
    valAccuracy: 63.36,
    valRecall: 68.04,
    valAuc: 0.7036,
    champion: false,
    note: 'High recall (68.04%) but lower precision and higher validation loss.'
  }
];

export const EDA_GALLERY = [
  {
    id: 1,
    filename: '01_target_distribution.png',
    title: '1. Target Class Distribution: 10-Year CHD Risk',
    chartType: 'Annotated Bar Chart',
    whatItShows: 'The count and percentage of patients who developed coronary heart disease (644 patients, 15.2%) versus those who remained disease-free (3,596 patients, 84.8%).',
    whyCreated: 'To evaluate target variable balance. A 5.58:1 imbalance requires class weighting or sampling adjustments to prevent majority-class bias.',
    actualInsights: 'Authentic epidemiological prevalence: only 15.2% of the general cohort experiences a CHD event within 10 years. Naive accuracy would achieve 84.8% by predicting negative for everyone; hence ROC-AUC and Recall are the true metrics of success.'
  },
  {
    id: 2,
    filename: '02_age_distribution.png',
    title: '2. Age Distribution Stratified by 10-Year CHD Outcome',
    chartType: 'Stacked Histogram + Kernel Density Estimate (KDE)',
    whatItShows: 'Age distribution histograms stratified by heart disease outcome across age 32 to 70.',
    whyCreated: 'To investigate the demographic risk gradient and determine whether age functions as an independent risk modifier.',
    actualInsights: 'The mean age for unaffected patients is 48.8 years, whereas for CHD-positive patients it is 54.1 years. Relative incidence increases non-linearly past age 50.'
  },
  {
    id: 3,
    filename: '03_correlation_heatmap.png',
    title: '3. Pearson Correlation Heatmap Among Features and Outcome',
    chartType: 'Triangular Correlation Heatmap (Annotated Pearson r)',
    whatItShows: 'Pairwise linear correlation coefficients across all 15 clinical features and the binary target.',
    whyCreated: 'To uncover collinear feature clusters (multi-collinearity) and pinpoint features with direct linear association to TenYearCHD.',
    actualInsights: 'Strong collinearity between systolic and diastolic BP (r = 0.78), and between glucose and diabetes (r = 0.62). Systolic BP (r = 0.22) and age (r = 0.23) exhibit the highest linear correlation with TenYearCHD.'
  },
  {
    id: 4,
    filename: '04_outlier_boxplots.png',
    title: '4. Clinical Outlier Inspection Across Target Classes (IQR Boxplots)',
    chartType: 'Multi-Panel Box & Whisker Plots',
    whatItShows: 'Distribution quartiles, median markers, and statistical outliers (points > 1.5 * IQR) for Systolic BP, Total Cholesterol, Fasting Glucose, and BMI.',
    whyCreated: 'To diagnose distribution tails and confirm our clinical decision not to delete extreme medical observations.',
    actualInsights: 'Extremes in systolic BP (up to 295 mmHg) and glucose (up to 394 mg/dL) belong overwhelmingly to patients with heart disease. Deleting these would eliminate the highest-risk clinical events.'
  },
  {
    id: 5,
    filename: '05_feature_distributions.png',
    title: '5. Feature-Wise Continuous Kernel Density Distributions',
    chartType: 'Continuous Density Curves (Overlaid KDE)',
    whatItShows: 'Comparative probability density curves for healthy vs CHD populations across systolic blood pressure, total cholesterol, and fasting glucose.',
    whyCreated: 'To visually observe density shifts and skewness in continuous biological markers.',
    actualInsights: 'Systolic BP exhibits a clear rightward shift for the CHD-positive group (mode shifts from 124 mmHg to 142 mmHg). Fasting glucose features a pronounced heavy right tail representing diabetic cohorts.'
  },
  {
    id: 6,
    filename: '06_age_vs_sysbp_scatterplot.png',
    title: '6. Relationship Between Patient Age, Systolic BP, and 10-Year CHD',
    chartType: 'Bi-Variate Scatterplot with Hypertension Cutoff',
    whatItShows: 'Scatter plot of patient age versus systolic blood pressure with a dashed reference line at 140 mmHg (Stage 2 Hypertension).',
    whyCreated: 'To explore the multi-dimensional synergy between advancing age and chronic arterial pressure elevation.',
    actualInsights: 'Positive CHD cases cluster heavily in the upper-right quadrant (age > 50 and systolic BP > 140 mmHg), demonstrating that vascular shearing and arterial stiffening compound with age.'
  },
  {
    id: 7,
    filename: '07_feature_importance.png',
    title: '7. Feature Importance via Permutation ROC-AUC Metric',
    chartType: 'Horizontal Bar Chart with Standard Deviation Error Bars',
    whatItShows: 'Permutation feature importance showing the mean decrease in validation ROC-AUC when each feature is randomly shuffled.',
    whyCreated: 'To empirically rank features by their true non-linear predictive utility in predicting heart disease.',
    actualInsights: 'Top 5 predictors: 1. Systolic Blood Pressure (sysBP), 2. Age, 3. Fasting Blood Glucose, 4. Cigarettes Per Day (cigsPerDay), and 5. Total Serum Cholesterol (totChol).'
  }
];

export const EVALUATION_GALLERY = [
  {
    id: 1,
    filename: '01_loss_vs_epoch.png',
    title: '1. Training and Validation Loss vs Epoch',
    chartType: 'Loss Trajectory Curve',
    whatItShows: 'Binary cross-entropy loss across 28 training epochs for both training and validation sets.',
    keyTakeaway: 'Validation loss smoothly drops and stabilizes near 0.61. EarlyStopping at epoch 28 halted training before validation loss could diverge, preventing overfitting.'
  },
  {
    id: 2,
    filename: '02_accuracy_vs_epoch.png',
    title: '2. Training and Validation Accuracy vs Epoch',
    chartType: 'Epoch Accuracy Trajectory',
    whatItShows: 'Accuracy progression reaching ~70% on both training and validation folds.',
    keyTakeaway: 'The close tracking between training and validation accuracy confirms appropriate regularization (Dropout 0.10 + L2 weight decay + Batch Normalization).'
  },
  {
    id: 3,
    filename: '03_confusion_matrix.png',
    title: '3. Test Confusion Matrix (Threshold = 0.50)',
    chartType: 'Annotated Heatmap with Raw Counts & Percentages',
    whatItShows: 'TN = 387 (60.8%), FP = 153 (24.1%), FN = 44 (6.9%), TP = 52 (8.2%) out of 636 unseen test patients.',
    keyTakeaway: 'The model achieves 54.17% recall and 71.67% specificity at threshold 0.50. Shifting to threshold 0.35 raises recall to 79.17%, slashing false negatives from 44 to 20.'
  },
  {
    id: 4,
    filename: '04_roc_curve.png',
    title: '4. Receiver Operating Characteristic (ROC) Curve',
    chartType: 'ROC Curve with Area Under Curve (AUC)',
    whatItShows: 'Trade-off between True Positive Rate (Sensitivity) and False Positive Rate across all decision thresholds. AUC = 0.679.',
    keyTakeaway: 'Substantially outperforms random chance (AUC 0.50). In epidemiological 10-year forecasts without genetic markers, AUC ~0.70 is standard for the Framingham cohort.'
  }
];

export const BEN_FRY_STAGES = [
  {
    stage: 1,
    name: 'Acquire',
    question: 'Where and how is the clinical data collected?',
    action: 'Obtained the authentic Framingham Heart Study cohort (4,240 records across 16 fields) from the NIH BioLINCC and Kaggle repositories.',
    datasetExample: 'Loaded framingham.csv containing patient surveys, biometric readings, and 10-year follow-up status.'
  },
  {
    stage: 2,
    name: 'Parse',
    question: 'How is the raw text converted into structured types?',
    action: 'Enforced formal schema constraints, identifying continuous variables (sysBP, totChol), binary categories (male, diabetes), and ordinal fields (education).',
    datasetExample: 'Converted education from floating text to ordinal categories [1, 2, 3, 4] and verified float64 physiological readings.'
  },
  {
    stage: 3,
    name: 'Filter',
    question: 'How do we clean noise without removing valid clinical truth?',
    action: 'Applied clinical-aware imputation (mode for BPMeds, conditional median for cigarettes, median for glucose) while explicitly retaining medical outliers.',
    datasetExample: 'Preserved extreme systolic BP readings (> 200 mmHg) because they represent clinical hypertensive emergencies.'
  },
  {
    stage: 4,
    name: 'Mine',
    question: 'What statistical patterns and relationships exist?',
    action: 'Computed Pearson correlation coefficients, interquartile ranges, class distribution ratios, and permutation feature importance.',
    datasetExample: 'Discovered high collinearity between systolic and diastolic BP (r = 0.78) and identified sysBP as the top risk driver.'
  },
  {
    stage: 5,
    name: 'Represent',
    question: 'What foundational chart forms communicate the signals best?',
    action: 'Selected stacked histograms for demographics, correlation heatmaps, boxplots for dispersion, and ROC curves for discriminator power.',
    datasetExample: 'Constructed an age vs systolic blood pressure scatterplot to capture the dual impact of vascular aging.'
  },
  {
    stage: 6,
    name: 'Refine',
    question: 'How can clarity, aesthetics, and accessibility be elevated?',
    action: 'Added clinical threshold markers (e.g., 140 mmHg hypertension line), readable legends, percentage annotations, and publication styling.',
    datasetExample: 'Bar chart labels showing both exact patient count (e.g., 3,596) and precise cohort percentage (84.8%).'
  },
  {
    stage: 7,
    name: 'Interact',
    question: 'How can the audience explore the visualization dynamically?',
    action: 'Built interactive decision threshold sliders, patient profile selectors, and real-time inference simulators.',
    datasetExample: 'Users can drag the classification cutoff slider from 0.10 to 0.90 to observe how sensitivity and specificity trade off.'
  }
];

export const REFERENCES_IEEE = [
  {
    citation: '[1] T. R. Dawber, G. F. Meadors, and F. E. Moore, "Epidemiological approaches to heart disease: the Framingham Study," American Journal of Public Health, vol. 41, no. 3, pp. 279-286, Mar. 1951. DOI: 10.2105/ajph.41.3.279.',
    authorYear: 'T. R. Dawber et al., 1951',
    objective: 'Establish the foundational prospective epidemiological methodology for tracking cardiovascular risk factors over multi-decade follow-ups.',
    method: 'Longitudinal cohort surveillance of 5,209 adult residents in Framingham, Massachusetts.',
    findings: 'First large-scale clinical study to conclusively prove links between hypertension, hypercholesterolemia, smoking, and coronary atherosclerosis.',
    relevance: 'Validates the clinical provenance, epidemiological integrity, and variable definitions of the Framingham dataset used in this project.'
  },
  {
    citation: '[2] P. W. Wilson, R. B. D\'Agostino, D. Levy, A. M. Belanger, H. Silbershatz, and W. B. Kannel, "Prediction of coronary heart disease using risk factor categories," Circulation, vol. 97, no. 18, pp. 1837-1847, May 1998. DOI: 10.1161/01.cir.97.18.1837.',
    authorYear: 'P. W. Wilson et al., 1998',
    objective: 'Develop standardized clinical scoring algorithms for calculating 10-year coronary heart disease probability.',
    method: 'Cox proportional hazards regression modeling across 2,489 male and 2,856 female participants.',
    findings: 'Formulated the classic Framingham Risk Score, establishing age, systolic BP, total cholesterol, smoking, and diabetes as core risk weights.',
    relevance: 'Provides the theoretical and medical basis for selecting the 15 input features and the 10-year CHD target variable.'
  },
  {
    citation: '[3] L. Grinsztajn, E. Oyallon, and G. Varoquaux, "Why do tree-based models still outperform deep learning on typical tabular data?" in Advances in Neural Information Processing Systems (NeurIPS), vol. 35, pp. 507-520, Dec. 2022.',
    authorYear: 'L. Grinsztajn, E. Oyallon, and G. Varoquaux, 2022',
    objective: 'Empirically investigate the inductive biases of deep neural networks versus decision tree ensembles on typical tabular datasets.',
    method: 'Benchmark evaluation of MLPs, ResNets, Saint, XGBoost, and Random Forests across 45 diverse tabular datasets.',
    findings: 'Tabular data lacks rotational invariance; deep neural networks require strict regularization (Batch Normalization, Dropout, Early Stopping) to avoid overfitting.',
    relevance: 'Directly guided our hyperparameter tuning decision to select a compact 2-layer MLP over deeper architectures to maximize validation ROC-AUC.'
  },
  {
    citation: '[4] M. Abadi et al., "TensorFlow: A system for large-scale machine learning," in 12th USENIX Symposium on Operating Systems Design and Implementation (OSDI), pp. 265-283, Nov. 2016.',
    authorYear: 'M. Abadi et al., 2016',
    objective: 'Describe the computational architecture, execution pipeline, and automatic differentiation of the TensorFlow platform.',
    method: 'Dataflow computational graph execution across heterogeneous hardware accelerators (CPU, GPU, TPU).',
    findings: 'Demonstrated high-throughput model training, flexible layer abstraction via Keras, and unified production deployment.',
    relevance: 'Primary deep learning engine used in this project to construct, train, compile, and serialize the Keras MLP model.'
  },
  {
    citation: '[5] F. Pedregosa et al., "Scikit-learn: Machine Learning in Python," Journal of Machine Learning Research (JMLR), vol. 12, pp. 2825-2830, Oct. 2011.',
    authorYear: 'F. Pedregosa et al., 2011',
    objective: 'Provide a unified, highly optimized Python library for statistical machine learning and data preprocessing.',
    method: 'Consistent object-oriented estimators and transformers written in Cython and NumPy.',
    findings: 'Established standardized APIs for cross-validation, feature scaling, permutation feature importance, and confusion matrices.',
    relevance: 'Utilized for zero-leakage StandardScaler, stratified train/val/test splits, permutation importance calculation, and ROC curve generation.'
  }
];
