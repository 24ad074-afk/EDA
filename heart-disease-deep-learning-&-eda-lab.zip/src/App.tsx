/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  Heart,
  Activity,
  FileText,
  Brain,
  BarChart3,
  Layers,
  ShieldCheck,
  AlertTriangle,
  Download,
  Code2,
  CheckCircle2,
  Sliders,
  Eye,
  BookOpen,
  Info,
  Sparkles,
  RefreshCw,
  Copy,
  Check,
  ChevronRight,
  TrendingUp,
  Stethoscope,
  Microscope,
  FileSpreadsheet
} from 'lucide-react';

import {
  FEATURES_LIST,
  PRESET_PATIENTS,
  VERIFIED_METRICS,
  TUNING_CONFIGS,
  EDA_GALLERY,
  EVALUATION_GALLERY,
  BEN_FRY_STAGES,
  REFERENCES_IEEE,
  FeatureSpec
} from './project_data';
import { predictHeartDiseaseRisk } from './model_inference';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'calculator' | 'eda' | 'stages' | 'architecture' | 'evaluation' | 'code' | 'report'
  >('calculator');

  // Patient Simulator State
  const [patientFeatures, setPatientFeatures] = useState<Record<string, number>>(() => {
    const defaults: Record<string, number> = {};
    FEATURES_LIST.forEach((f) => {
      defaults[f.name] = f.defaultVal;
    });
    return defaults;
  });

  const [decisionThreshold, setDecisionThreshold] = useState<number>(0.35);
  const [activePreset, setActivePreset] = useState<string>('Custom');
  const [selectedEdaId, setSelectedEdaId] = useState<number>(1);
  const [selectedEvalId, setSelectedEvalId] = useState<number>(3);
  const [selectedCodeFile, setSelectedCodeFile] = useState<string>('preprocessing.py');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Compute live prediction
  const prediction = useMemo(() => {
    return predictHeartDiseaseRisk(patientFeatures);
  }, [patientFeatures]);

  const isPositive = prediction.probability >= decisionThreshold;

  const handleFeatureChange = (name: string, value: number) => {
    setPatientFeatures((prev) => ({
      ...prev,
      [name]: value,
      // Clinical consistency: if non-smoker, cigsPerDay is 0
      ...(name === 'currentSmoker' && value === 0 ? { cigsPerDay: 0 } : {})
    }));
    setActivePreset('Custom');
  };

  const applyPreset = (preset: typeof PRESET_PATIENTS[0]) => {
    setPatientFeatures({ ...preset.values });
    setActivePreset(preset.name);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Banner Disclaimer */}
      <header className="bg-slate-900/90 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-rose-400 flex items-center justify-center shadow-lg shadow-rose-900/40 text-white font-bold">
                <Heart className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-bold tracking-tight text-white">
                    CardioVision Deep Learning Lab
                  </h1>
                  <span className="text-[10px] uppercase tracking-wider font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded">
                    Framingham Cohort Benchmark
                  </span>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">
                  Multilayer Perceptron (MLP) Neural Network • 15 Clinical Predictors • 7-Stage Visualization
                </p>
              </div>
            </div>

            {/* Quick Stats / Action Links */}
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-4 text-xs font-mono text-slate-400 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
                <span>N = 4,240</span>
                <span className="text-slate-600">|</span>
                <span className="text-emerald-400">Val AUC = 0.711</span>
                <span className="text-slate-600">|</span>
                <span className="text-rose-400">Test AUC = 0.679</span>
              </div>
              <a
                href="/downloads/heart_disease_analysis.ipynb"
                download="heart_disease_analysis.ipynb"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium transition shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Notebook (.ipynb)</span>
              </a>
            </div>
          </div>

          {/* Navigation Bar */}
          <nav className="flex space-x-1 overflow-x-auto py-2 scrollbar-none border-t border-slate-800/60 text-xs font-medium">
            {[
              { id: 'calculator', label: 'Patient Risk Simulator', icon: Stethoscope },
              { id: 'eda', label: 'EDA Gallery (7 Visualizations)', icon: BarChart3 },
              { id: 'stages', label: '7 Stages of Visualization', icon: Layers },
              { id: 'architecture', label: 'MLP Architecture & Tuning', icon: Brain },
              { id: 'evaluation', label: 'Model Evaluation & ROC', icon: Activity },
              { id: 'code', label: 'Code & Artifacts Explorer', icon: Code2 },
              { id: 'report', label: 'Academic Report & Literature', icon: BookOpen }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg whitespace-nowrap transition-all duration-150 ${
                    isActive
                      ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-rose-400' : 'text-slate-400'}`} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Academic Disclaimer Callout */}
        <div className="mb-6 p-3.5 bg-rose-950/30 border border-rose-800/40 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="text-xs text-rose-200/90 leading-relaxed">
            <strong className="text-rose-300 font-semibold uppercase tracking-wide">
              Academic & Research Disclaimer:
            </strong>{' '}
            This application is an educational prototype developed for deep learning coursework, exploratory
            data analysis, and algorithmic benchmarking on the Framingham Heart Study cohort. It is{' '}
            <strong>NOT a clinically validated diagnostic device</strong> and should never be used for actual
            medical decisions or patient diagnosis.
          </div>
        </div>

        {/* =========================================================================
            TAB 1: PATIENT RISK SIMULATOR
        ========================================================================= */}
        {activeTab === 'calculator' && (
          <div className="space-y-6">
            {/* Header & Presets */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Stethoscope className="w-5 h-5 text-rose-400" />
                    Interactive Patient Clinical Profile
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Feed patient parameters into the trained Keras Multilayer Perceptron (MLP) to compute 10-year
                    Coronary Heart Disease risk.
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-slate-400 font-medium">Cohort Presets:</span>
                  {PRESET_PATIENTS.map((p) => (
                    <button
                      key={p.name}
                      onClick={() => applyPreset(p)}
                      className={`text-xs px-3 py-1.5 rounded-lg border transition ${
                        activePreset === p.name
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-semibold'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                      }`}
                    >
                      {p.name.split(' ')[0]} {p.name.split(' ')[1]}
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      const defaults: Record<string, number> = {};
                      FEATURES_LIST.forEach((f) => (defaults[f.name] = f.defaultVal));
                      setPatientFeatures(defaults);
                      setActivePreset('Custom');
                    }}
                    className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700 flex items-center gap-1"
                    title="Reset to cohort averages"
                  >
                    <RefreshCw className="w-3 h-3" /> Reset
                  </button>
                </div>
              </div>
            </div>

            {/* Inputs & Output Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Feature Input Controls (8 cols) */}
              <div className="lg:col-span-8 space-y-5">
                {/* 1. Demographics & Lifestyle */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    1. Demographics & Lifestyle Factors (5 Features)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Sex */}
                    <div>
                      <label className="text-xs font-medium text-slate-300 block mb-1.5">
                        Biological Sex
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { value: 0, label: 'Female' },
                          { value: 1, label: 'Male' }
                        ].map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => handleFeatureChange('male', opt.value)}
                            className={`py-1.5 text-xs font-medium rounded-lg border transition ${
                              patientFeatures.male === opt.value
                                ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                                : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Age */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300">
                          Patient Age
                        </label>
                        <span className="text-xs font-mono font-bold text-blue-400">
                          {patientFeatures.age} years
                        </span>
                      </div>
                      <input
                        type="range"
                        min="30"
                        max="80"
                        step="1"
                        value={patientFeatures.age}
                        onChange={(e) => handleFeatureChange('age', Number(e.target.value))}
                        className="w-full accent-blue-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>30 yrs</span>
                        <span>Coh. Avg: 49.7</span>
                        <span>80 yrs</span>
                      </div>
                    </div>

                    {/* Education */}
                    <div>
                      <label className="text-xs font-medium text-slate-300 block mb-1.5">
                        Highest Education Level
                      </label>
                      <select
                        value={patientFeatures.education}
                        onChange={(e) => handleFeatureChange('education', Number(e.target.value))}
                        className="w-full bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-2 focus:ring-1 focus:ring-rose-500 outline-none"
                      >
                        <option value={1}>1: Some High School</option>
                        <option value={2}>2: High School / GED</option>
                        <option value={3}>3: Some College</option>
                        <option value={4}>4: College Graduate</option>
                      </select>
                    </div>

                    {/* Smoking Status & Cigs/Day */}
                    <div>
                      <label className="text-xs font-medium text-slate-300 block mb-1.5">
                        Tobacco Smoking Status
                      </label>
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        {[
                          { value: 0, label: 'Non-Smoker' },
                          { value: 1, label: 'Active Smoker' }
                        ].map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => handleFeatureChange('currentSmoker', opt.value)}
                            className={`py-1.5 text-xs font-medium rounded-lg border transition ${
                              patientFeatures.currentSmoker === opt.value
                                ? 'bg-amber-600 text-white border-amber-500 shadow-sm'
                                : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>

                      {patientFeatures.currentSmoker === 1 && (
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[11px] text-slate-400">Daily Cigarettes</span>
                            <span className="text-xs font-mono font-bold text-amber-400">
                              {patientFeatures.cigsPerDay} cigs/day
                            </span>
                          </div>
                          <input
                            type="range"
                            min="1"
                            max="60"
                            step="1"
                            value={patientFeatures.cigsPerDay}
                            onChange={(e) => handleFeatureChange('cigsPerDay', Number(e.target.value))}
                            className="w-full accent-amber-500 bg-slate-800 rounded-lg cursor-pointer h-1.5"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* 2. Medical History & Pre-existing Conditions */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    2. Medical History & Conditions (5 Features)
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { key: 'BPMeds', label: 'Blood Pressure Meds' },
                      { key: 'prevalentStroke', label: 'History of Stroke' },
                      { key: 'prevalentHyp', label: 'Prevalent Hypertension' },
                      { key: 'diabetes', label: 'Diagnosed Diabetes' }
                    ].map((item) => {
                      const isChecked = patientFeatures[item.key] === 1;
                      return (
                        <button
                          key={item.key}
                          type="button"
                          onClick={() => handleFeatureChange(item.key, isChecked ? 0 : 1)}
                          className={`p-3 rounded-xl border text-left transition ${
                            isChecked
                              ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                              : 'bg-slate-800/60 border-slate-700/80 text-slate-400 hover:bg-slate-800'
                          }`}
                        >
                          <div className="text-[11px] font-medium leading-tight mb-2">
                            {item.label}
                          </div>
                          <span
                            className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded ${
                              isChecked ? 'bg-rose-500/30 text-rose-300' : 'bg-slate-700 text-slate-400'
                            }`}
                          >
                            {isChecked ? 'Positive (1)' : 'Negative (0)'}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Heart Rate */}
                  <div className="mt-4 pt-4 border-t border-slate-800/80">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-medium text-slate-300">
                        Resting Heart Rate (Pulse)
                      </label>
                      <span className="text-xs font-mono font-bold text-emerald-400">
                        {patientFeatures.heartRate} bpm
                      </span>
                    </div>
                    <input
                      type="range"
                      min="45"
                      max="135"
                      step="1"
                      value={patientFeatures.heartRate}
                      onChange={(e) => handleFeatureChange('heartRate', Number(e.target.value))}
                      className="w-full accent-emerald-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                      <span>45 bpm</span>
                      <span>Normal: 60 - 100</span>
                      <span>135 bpm</span>
                    </div>
                  </div>
                </div>

                {/* 3. Physiological & Laboratory Biometrics */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    3. Biometric & Laboratory Biomarkers (5 Features)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Systolic BP */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                          Systolic Blood Pressure
                          <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1 rounded">Top Predictor</span>
                        </label>
                        <span className="text-xs font-mono font-bold text-rose-400">
                          {patientFeatures.sysBP} mmHg
                        </span>
                      </div>
                      <input
                        type="range"
                        min="85"
                        max="220"
                        step="1"
                        value={patientFeatures.sysBP}
                        onChange={(e) => handleFeatureChange('sysBP', Number(e.target.value))}
                        className="w-full accent-rose-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>Normal: &lt;120</span>
                        <span>Hypertension: &ge;140</span>
                        <span>Crisis: &ge;180</span>
                      </div>
                    </div>

                    {/* Diastolic BP */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300">
                          Diastolic Blood Pressure
                        </label>
                        <span className="text-xs font-mono font-bold text-indigo-400">
                          {patientFeatures.diaBP} mmHg
                        </span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="130"
                        step="1"
                        value={patientFeatures.diaBP}
                        onChange={(e) => handleFeatureChange('diaBP', Number(e.target.value))}
                        className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>50 mmHg</span>
                        <span>Normal: &lt;80</span>
                        <span>130 mmHg</span>
                      </div>
                    </div>

                    {/* Total Cholesterol */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300">
                          Total Serum Cholesterol
                        </label>
                        <span className="text-xs font-mono font-bold text-cyan-400">
                          {patientFeatures.totChol} mg/dL
                        </span>
                      </div>
                      <input
                        type="range"
                        min="120"
                        max="420"
                        step="1"
                        value={patientFeatures.totChol}
                        onChange={(e) => handleFeatureChange('totChol', Number(e.target.value))}
                        className="w-full accent-cyan-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>Desirable: &lt;200</span>
                        <span>Borderline: 200-239</span>
                        <span>High: &ge;240</span>
                      </div>
                    </div>

                    {/* Fasting Glucose */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300">
                          Fasting Blood Glucose
                        </label>
                        <span className="text-xs font-mono font-bold text-orange-400">
                          {patientFeatures.glucose} mg/dL
                        </span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="280"
                        step="1"
                        value={patientFeatures.glucose}
                        onChange={(e) => handleFeatureChange('glucose', Number(e.target.value))}
                        className="w-full accent-orange-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>Normal: 70-99</span>
                        <span>Prediabetes: 100-125</span>
                        <span>Diabetes: &ge;126</span>
                      </div>
                    </div>

                    {/* Body Mass Index (BMI) */}
                    <div className="sm:col-span-2">
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-slate-300">
                          Body Mass Index (BMI)
                        </label>
                        <span className="text-xs font-mono font-bold text-purple-400">
                          {patientFeatures.BMI.toFixed(1)} kg/m²
                        </span>
                      </div>
                      <input
                        type="range"
                        min="16.0"
                        max="46.0"
                        step="0.1"
                        value={patientFeatures.BMI}
                        onChange={(e) => handleFeatureChange('BMI', Number(e.target.value))}
                        className="w-full accent-purple-500 bg-slate-800 rounded-lg cursor-pointer h-2"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                        <span>Underweight: &lt;18.5</span>
                        <span>Normal: 18.5 - 24.9</span>
                        <span>Overweight: 25 - 29.9</span>
                        <span>Obese: &ge;30</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Real-Time Prediction Card (4 cols) */}
              <div className="lg:col-span-4 space-y-5">
                <div className="bg-gradient-to-b from-slate-900 to-slate-925 border border-slate-800 rounded-2xl p-5 sticky top-24 shadow-xl">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-rose-400" />
                      Model Inference Result
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      Live Forward Pass
                    </span>
                  </div>

                  {/* Probability Display */}
                  <div className="my-5 text-center">
                    <div className="text-5xl font-black tracking-tight text-white font-mono">
                      {prediction.percentage}%
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      Predicted 10-Year Coronary Heart Disease Probability
                    </div>

                    {/* Risk Badge */}
                    <div className="mt-3">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full border ${
                          prediction.riskTier === 'Elevated / High Risk'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                            : prediction.riskTier === 'Moderate Risk'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        }`}
                      >
                        {prediction.riskTier === 'Elevated / High Risk' ? (
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                        {prediction.riskTier}
                      </span>
                    </div>
                  </div>

                  {/* Decision Threshold Controller */}
                  <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2 mb-4">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-300 font-medium flex items-center gap-1">
                        <Sliders className="w-3.5 h-3.5 text-rose-400" />
                        Decision Cutoff ($\tau$)
                      </span>
                      <span className="font-mono font-bold text-rose-400">
                        {decisionThreshold.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.10"
                      max="0.80"
                      step="0.05"
                      value={decisionThreshold}
                      onChange={(e) => setDecisionThreshold(Number(e.target.value))}
                      className="w-full accent-rose-500 bg-slate-800 rounded-lg cursor-pointer h-1.5"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>0.10 (High Sensitivity)</span>
                      <span>0.35 (Screening)</span>
                      <span>0.50 (Default)</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-snug">
                      At cutoff <strong className="text-slate-200">{decisionThreshold.toFixed(2)}</strong>:
                      classified as{' '}
                      <strong className={isPositive ? 'text-rose-400' : 'text-emerald-400'}>
                        {isPositive ? 'POSITIVE FOR 10-YEAR CHD RISK' : 'NEGATIVE FOR 10-YEAR CHD RISK'}
                      </strong>
                      .
                    </p>
                  </div>

                  {/* Top Detected Risk Contributors */}
                  <div className="space-y-2 text-xs">
                    <div className="font-semibold text-slate-300 flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                      Individual Risk Factor Breakdown:
                    </div>
                    {prediction.topRiskContributors.length > 0 ? (
                      <div className="space-y-1.5">
                        {prediction.topRiskContributors.map((c, idx) => (
                          <div
                            key={idx}
                            className="p-2 bg-slate-800/60 rounded-lg border border-slate-700/60 flex items-center justify-between text-[11px]"
                          >
                            <span className="text-slate-300 font-medium">{c.feature}</span>
                            <span className="text-rose-300 font-mono text-[10px]">{c.impact}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-2 bg-emerald-950/20 border border-emerald-800/40 rounded-lg text-emerald-300 text-[11px]">
                        No acute high-risk clinical anomalies detected for this patient profile.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 2: EXPLORATORY DATA ANALYSIS (EDA) GALLERY
        ========================================================================= */}
        {activeTab === 'eda' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-rose-400" />
                Exploratory Data Analysis: Seven Academic Visualizations
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Visualizing clinical patterns, multi-collinearity, outliers, and feature importance across the
                authentic 4,240-patient Framingham cohort.
              </p>
            </div>

            {/* Selector Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
              {EDA_GALLERY.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedEdaId(item.id)}
                  className={`p-2.5 rounded-xl border text-left transition text-xs ${
                    selectedEdaId === item.id
                      ? 'bg-rose-500/20 border-rose-500/50 text-rose-200 font-semibold shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-850 hover:text-slate-200'
                  }`}
                >
                  <span className="block text-[10px] uppercase font-bold text-rose-400 mb-0.5">
                    Plot #{item.id}
                  </span>
                  <span className="line-clamp-2 leading-tight">{item.title.split('. ')[1]}</span>
                </button>
              ))}
            </div>

            {/* Active EDA Display */}
            {(() => {
              const currentEda = EDA_GALLERY.find((e) => e.id === selectedEdaId) || EDA_GALLERY[0];
              return (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* High-Res Image Display */}
                  <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-center items-center">
                    <img
                      src={`/outputs/eda_visualizations/${currentEda.filename}`}
                      alt={currentEda.title}
                      className="rounded-xl border border-slate-800 max-h-[500px] w-auto object-contain shadow-lg"
                    />
                    <div className="mt-3 flex items-center justify-between w-full text-xs text-slate-500 px-2 font-mono">
                      <span>Saved at: outputs/eda_visualizations/{currentEda.filename}</span>
                      <span>DPI: 300 (Publication Ready)</span>
                    </div>
                  </div>

                  {/* Academic Commentary Panel */}
                  <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-500/20">
                        {currentEda.chartType}
                      </span>
                      <h3 className="text-base font-bold text-white mt-2">{currentEda.title}</h3>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
                        <strong className="text-slate-200 block mb-1 font-semibold flex items-center gap-1.5">
                          <Eye className="w-3.5 h-3.5 text-blue-400" />
                          What the Chart Shows:
                        </strong>
                        <p className="text-slate-400 leading-relaxed">{currentEda.whatItShows}</p>
                      </div>

                      <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
                        <strong className="text-slate-200 block mb-1 font-semibold flex items-center gap-1.5">
                          <Brain className="w-3.5 h-3.5 text-purple-400" />
                          Why It Was Created:
                        </strong>
                        <p className="text-slate-400 leading-relaxed">{currentEda.whyCreated}</p>
                      </div>

                      <div className="p-3 bg-rose-950/20 rounded-xl border border-rose-900/30">
                        <strong className="text-rose-300 block mb-1 font-semibold flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                          Verified Insights from Actual Dataset:
                        </strong>
                        <p className="text-rose-200/90 leading-relaxed">{currentEda.actualInsights}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* =========================================================================
            TAB 3: THE SEVEN STAGES OF DATA VISUALIZATION
        ========================================================================= */}
        {activeTab === 'stages' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-rose-400" />
                The Seven Stages of Data Visualization (Ben Fry Framework)
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Mapping the classical academic information design taxonomy to our deep learning cardiovascular
                pipeline.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
              {BEN_FRY_STAGES.map((s) => (
                <div
                  key={s.stage}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between hover:border-slate-700 transition"
                >
                  <div>
                    <div className="w-7 h-7 rounded-lg bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-bold font-mono text-xs mb-3">
                      0{s.stage}
                    </div>
                    <h3 className="text-sm font-bold text-white mb-1">{s.name}</h3>
                    <p className="text-[11px] text-rose-300/80 italic mb-3">{s.question}</p>
                    <div className="text-xs text-slate-400 space-y-2 leading-relaxed">
                      <p>{s.action}</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono bg-slate-950/50 p-2 rounded-lg">
                    <strong className="text-slate-400 block font-sans">Framingham Example:</strong>
                    {s.datasetExample}
                  </div>
                </div>
              ))}
            </div>

            {/* Deep Dive Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-rose-400" />
                Pedagogical Value of Fry's Seven Stages in Clinical Tabular Projects
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                In health informatics, jumping straight from raw data to deep learning models often leads to subtle,
                catastrophic failures (e.g., inadvertently deleting life-threatening blood pressure anomalies or
                experiencing target leakage during scaling). By dividing visualization into seven distinct computational
                phases—from initial acquisition and schema parsing through data filtering, mathematical mining, visual
                representation, typographic refinement, and real-time interaction—we ensure that every design choice is
                clinically defensible and mathematically rigorous.
              </p>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 4: DEEP LEARNING ARCHITECTURE & TUNING
        ========================================================================= */}
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Brain className="w-5 h-5 text-rose-400" />
                Multilayer Perceptron (MLP) Deep Learning Architecture & Tuning
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Constructed using TensorFlow 2.x and Keras, evaluated with EarlyStopping across three hyperparameter
                candidates.
              </p>
            </div>

            {/* Neural Net Schematic */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Microscope className="w-4 h-4 text-blue-400" />
                Sequential Network Topology (Champion Architecture)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs font-mono">
                {/* Input */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-blue-400 uppercase font-bold">Input Layer</span>
                    <h4 className="text-sm font-bold text-white mt-1">15 Features</h4>
                    <p className="text-[11px] text-slate-400 mt-1 font-sans">
                      Standardized patient biometrics and demographic flags.
                    </p>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-3 border-t border-slate-850 pt-2">
                    Shape: (Batch, 15)
                  </div>
                </div>

                {/* Hidden 1 */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-rose-400 uppercase font-bold">Hidden Layer 1</span>
                    <h4 className="text-sm font-bold text-white mt-1">Dense 32 + ReLU</h4>
                    <ul className="text-[11px] text-slate-400 mt-1 space-y-1 font-sans list-disc list-inside">
                      <li>Batch Normalization</li>
                      <li>Dropout (10%)</li>
                      <li>L2 Regularizer (1e-4)</li>
                    </ul>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-3 border-t border-slate-850 pt-2">
                    Params: 512 + 128 BN
                  </div>
                </div>

                {/* Hidden 2 */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-purple-400 uppercase font-bold">Hidden Layer 2</span>
                    <h4 className="text-sm font-bold text-white mt-1">Dense 16 + ReLU</h4>
                    <ul className="text-[11px] text-slate-400 mt-1 space-y-1 font-sans list-disc list-inside">
                      <li>Batch Normalization</li>
                      <li>Dropout (10%)</li>
                      <li>L2 Regularizer (1e-4)</li>
                    </ul>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-3 border-t border-slate-850 pt-2">
                    Params: 528 + 64 BN
                  </div>
                </div>

                {/* Output */}
                <div className="p-4 bg-slate-950 border border-emerald-900/40 rounded-xl flex flex-col justify-between bg-emerald-950/10">
                  <div>
                    <span className="text-[10px] text-emerald-400 uppercase font-bold">Output Layer</span>
                    <h4 className="text-sm font-bold text-emerald-300 mt-1">Dense 1 + Sigmoid</h4>
                    <p className="text-[11px] text-slate-400 mt-1 font-sans">
                      Probability P(CHD=1 | X) in range [0.0, 1.0].
                    </p>
                  </div>
                  <div className="text-[10px] text-emerald-500/80 mt-3 border-t border-slate-850 pt-2">
                    Params: 17
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 font-mono">
                <span>Total Network Parameters: 3,557 (Trainable: 1,153 • Non-Trainable: 96)</span>
                <span>Loss: Binary Cross-Entropy • Optimizer: Adam (lr=0.001)</span>
              </div>
            </div>

            {/* Hyperparameter Tuning Results Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-rose-400" />
                Hyperparameter Tuning Matrix & Model Selection
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Trained across three distinct architectural candidates using EarlyStopping on validation ROC-AUC:
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                      <th className="py-2.5 px-3">Configuration</th>
                      <th className="py-2.5 px-3">Hidden Topology</th>
                      <th className="py-2.5 px-3">Dropout</th>
                      <th className="py-2.5 px-3">Learning Rate</th>
                      <th className="py-2.5 px-3">Early Stop Epoch</th>
                      <th className="py-2.5 px-3">Val Loss</th>
                      <th className="py-2.5 px-3">Val Recall</th>
                      <th className="py-2.5 px-3 text-rose-400">Val ROC-AUC</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {TUNING_CONFIGS.map((c) => (
                      <tr
                        key={c.name}
                        className={c.champion ? 'bg-rose-500/10 font-bold text-white' : 'text-slate-300'}
                      >
                        <td className="py-2.5 px-3 font-sans flex items-center gap-1.5">
                          {c.champion && <Check className="w-3.5 h-3.5 text-rose-400" />}
                          {c.name}
                        </td>
                        <td className="py-2.5 px-3">{c.hiddenUnits}</td>
                        <td className="py-2.5 px-3">{c.dropout}</td>
                        <td className="py-2.5 px-3">{c.learningRate}</td>
                        <td className="py-2.5 px-3">Epoch {c.stoppedEpoch}</td>
                        <td className="py-2.5 px-3">{c.valLoss.toFixed(4)}</td>
                        <td className="py-2.5 px-3">{c.valRecall.toFixed(1)}%</td>
                        <td className="py-2.5 px-3 text-rose-400 font-bold">{c.valAuc.toFixed(4)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-4 p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs text-slate-400 leading-relaxed">
                <strong className="text-slate-200">Theoretical Conclusion:</strong> Config A ([32, 16] dense units)
                demonstrated the highest validation ROC-AUC (0.7113). In tabular epidemiological benchmarks with ~4,000
                samples, over-parameterized deep networks (e.g. Config C with 3 hidden layers) tend to plateau early or
                exhibit variance inflation, confirming empirical findings by Grinsztajn et al. (NeurIPS 2022).
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 5: MODEL EVALUATION & ROC
        ========================================================================= */}
        {activeTab === 'evaluation' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-rose-400" />
                Unbiased Test Evaluation (N = 636 Patients)
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Evaluating the champion model on the isolated test partition (540 negative cases, 96 positive cases).
              </p>
            </div>

            {/* Official Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { label: 'ROC-AUC Score', value: `${VERIFIED_METRICS.defaultThreshold.rocAuc.toFixed(4)}`, sub: 'Threshold Invariant' },
                { label: 'Accuracy (Std 0.50)', value: `${VERIFIED_METRICS.defaultThreshold.accuracy}%`, sub: '387 TN + 52 TP' },
                { label: 'Recall (Std 0.50)', value: `${VERIFIED_METRICS.defaultThreshold.recall}%`, sub: '52 of 96 Cases' },
                { label: 'Recall (Screening 0.35)', value: `${VERIFIED_METRICS.clinicalThreshold.recall}%`, sub: '76 of 96 Cases' },
                { label: 'Precision (Std 0.50)', value: `${VERIFIED_METRICS.defaultThreshold.precision}%`, sub: '52 / (52 + 153)' },
                { label: 'F1-Score (Std 0.50)', value: `${VERIFIED_METRICS.defaultThreshold.f1Score}`, sub: 'Harmonic Mean' }
              ].map((m, idx) => (
                <div key={idx} className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">{m.label}</div>
                  <div className="text-2xl font-black font-mono text-white mt-1">{m.value}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{m.sub}</div>
                </div>
              ))}
            </div>

            {/* 4 Evaluation Visualizations Gallery */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {EVALUATION_GALLERY.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedEvalId(item.id)}
                  className={`bg-slate-900 border rounded-2xl p-3 cursor-pointer transition ${
                    selectedEvalId === item.id
                      ? 'border-rose-500 shadow-md shadow-rose-950/30'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <img
                    src={`/outputs/evaluation_visualizations/${item.filename}`}
                    alt={item.title}
                    className="w-full h-44 object-contain rounded-xl bg-slate-950"
                  />
                  <div className="mt-2 text-xs font-bold text-white truncate">{item.title}</div>
                  <div className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-tight">
                    {item.keyTakeaway}
                  </div>
                </div>
              ))}
            </div>

            {/* Threshold Clinical Comparison */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Clinical Decision Threshold Trade-Off Analysis
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                In cardiovascular triage, False Negatives (FN) and False Positives (FP) carry asymmetric clinical costs.
                A False Negative individual with undiagnosed coronary stenosis receives no preventative therapy,
                risking fatal myocardial infarction. By contrast, a False Positive merely triggers non-invasive
                confirmatory testing (e.g. treadmill stress ECG or CT coronary calcium scan).
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Standard Threshold */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Default Threshold (&tau; = 0.50)
                  </span>
                  <div className="grid grid-cols-2 gap-2 mt-2 text-xs font-mono">
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">True Neg (TN)</div>
                      <div className="text-base font-bold text-white">387</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">False Pos (FP)</div>
                      <div className="text-base font-bold text-amber-400">153</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">False Neg (FN)</div>
                      <div className="text-base font-bold text-rose-400">44 (Missed)</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">True Pos (TP)</div>
                      <div className="text-base font-bold text-emerald-400">52 (Detected)</div>
                    </div>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-400">
                    Accuracy: 69.0% • Sensitivity (Recall): 54.2%
                  </div>
                </div>

                {/* Screening Threshold */}
                <div className="p-4 bg-slate-950 rounded-xl border border-rose-900/40 bg-rose-950/10">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-300">
                    Clinical Screening Threshold (&tau; = 0.35) [Recommended]
                  </span>
                  <div className="grid grid-cols-2 gap-2 mt-2 text-xs font-mono">
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">True Neg (TN)</div>
                      <div className="text-base font-bold text-white">249</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-500">False Pos (FP)</div>
                      <div className="text-base font-bold text-amber-400">291</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-rose-800/40 bg-rose-950/30">
                      <div className="text-[10px] text-rose-300">False Neg (FN)</div>
                      <div className="text-base font-bold text-rose-400">20 (Reduced by 55%!)</div>
                    </div>
                    <div className="p-2 bg-slate-900 rounded border border-emerald-800/40 bg-emerald-950/30">
                      <div className="text-[10px] text-emerald-300">True Pos (TP)</div>
                      <div className="text-base font-bold text-emerald-400">76 (79.2% Recall)</div>
                    </div>
                  </div>
                  <div className="mt-2 text-[11px] text-rose-200">
                    Accuracy: 51.1% • Sensitivity (Recall): 79.2% (Catches almost 80% of true cases)
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 6: CODE & ARTIFACTS EXPLORER
        ========================================================================= */}
        {activeTab === 'code' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Code2 className="w-5 h-5 text-rose-400" />
                Project Source Code & Deliverables
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Inspect runnable python modules, pipeline scripts, dependencies, and download offline project archives.
              </p>
            </div>

            {/* Download Deliverables Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                { file: 'heart_disease_analysis.ipynb', label: 'Jupyter Notebook', size: '24 KB', desc: 'Complete runnable notebook for Colab/VSCode' },
                { file: 'framingham.csv', label: 'Cohort Dataset', size: '188 KB', desc: '4,240 rows with 15 clinical features' },
                { file: 'heart_disease_mlp_model.keras', label: 'Trained Keras Model', size: '56 KB', desc: 'Serialized champion MLP weights' },
                { file: 'report.md', label: 'Academic Report', size: '17 KB', desc: 'Full markdown thesis with IEEE citations' }
              ].map((d) => (
                <a
                  key={d.file}
                  href={`/downloads/${d.file}`}
                  download={d.file}
                  className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl hover:border-rose-500/50 transition flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-rose-400 transition">
                      {d.label}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">{d.file} • {d.size}</div>
                    <div className="text-[10px] text-slate-500 mt-1">{d.desc}</div>
                  </div>
                  <Download className="w-4 h-4 text-slate-400 group-hover:text-rose-400 transition shrink-0 ml-2" />
                </a>
              ))}
            </div>

            {/* Code Viewer Panel */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800">
                <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
                  {[
                    'preprocessing.py',
                    'eda_visualizations.py',
                    'train_model.py',
                    'evaluate_model.py',
                    'app.py',
                    'requirements.txt'
                  ].map((fileName) => (
                    <button
                      key={fileName}
                      onClick={() => setSelectedCodeFile(fileName)}
                      className={`text-xs px-3 py-1.5 rounded-lg font-mono transition ${
                        selectedCodeFile === fileName
                          ? 'bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/30'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      {fileName}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => {
                    setCopiedCode(true);
                    setTimeout(() => setCopiedCode(false), 2000);
                  }}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 shrink-0 ml-2"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Code Display Content */}
              <div className="p-4 bg-slate-950 text-slate-300 text-xs font-mono max-h-[500px] overflow-y-auto leading-relaxed">
                {selectedCodeFile === 'preprocessing.py' && (
                  <pre>{`# Heart_Disease_Deep_Learning/src/preprocessing.py
# Step 2: Zero-Leakage Clinical Preprocessing Pipeline
import os, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

RANDOM_SEED = 42

def preprocess_and_split(csv_path: str):
    df = pd.read_csv(csv_path)
    
    # Clinical-aware imputation
    # cigsPerDay: 0 if non-smoker; smoker median if smoker
    smoker_median = df[df['currentSmoker'] == 1]['cigsPerDay'].median()
    df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 0), 'cigsPerDay'] = 0
    df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 1), 'cigsPerDay'] = smoker_median

    df['BPMeds'] = df['BPMeds'].fillna(df['BPMeds'].mode()[0])
    df['education'] = df['education'].fillna(df['education'].mode()[0])
    for col in ['totChol', 'BMI', 'heartRate', 'glucose']:
        df[col] = df[col].fillna(df[col].median())

    # Stratified Train (70%) / Val (15%) / Test (15%)
    X = df.drop(columns=['TenYearCHD'])
    y = df['TenYearCHD']
    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.30, random_state=RANDOM_SEED, stratify=y)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.50, random_state=RANDOM_SEED, stratify=y_temp)

    # Zero-leakage standardization strictly fit on X_train
    num_cols = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    scaler = StandardScaler()
    X_train_scaled = X_train.copy()
    X_val_scaled = X_val.copy()
    X_test_scaled = X_test.copy()

    X_train_scaled[num_cols] = scaler.fit_transform(X_train[num_cols])
    X_val_scaled[num_cols] = scaler.transform(X_val[num_cols])
    X_test_scaled[num_cols] = scaler.transform(X_test[num_cols])

    return X_train_scaled, y_train, X_val_scaled, y_val, X_test_scaled, y_test`}</pre>
                )}

                {selectedCodeFile === 'train_model.py' && (
                  <pre>{`# Heart_Disease_Deep_Learning/src/train_model.py
# Step 4: Multilayer Perceptron Deep Learning & Tuning
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers, callbacks

def build_mlp(input_dim):
    model = keras.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(32, activation='relu', kernel_regularizer=regularizers.l2(1e-4)),
        layers.BatchNormalization(),
        layers.Dropout(0.10),
        layers.Dense(16, activation='relu', kernel_regularizer=regularizers.l2(1e-4)),
        layers.BatchNormalization(),
        layers.Dropout(0.10),
        layers.Dense(1, activation='sigmoid')
    ])
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', keras.metrics.AUC(name='auc')]
    )
    return model

# Class weights to handle 85:15 imbalance
neg_count, pos_count = (y_train == 0).sum(), (y_train == 1).sum()
class_weights = {0: len(y_train)/(2.0*neg_count), 1: len(y_train)/(2.0*pos_count)}

# Early stopping on validation ROC-AUC
early_stop = callbacks.EarlyStopping(monitor='val_auc', mode='max', patience=15, restore_best_weights=True)
history = model.fit(X_train, y_train, validation_data=(X_val, y_val),
                    epochs=60, batch_size=32, class_weight=class_weights, callbacks=[early_stop])`}</pre>
                )}

                {selectedCodeFile === 'evaluate_model.py' && (
                  <pre>{`# Heart_Disease_Deep_Learning/src/evaluate_model.py
# Step 5: Unbiased Test Set Evaluation (N=636)
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, roc_auc_score, confusion_matrix

y_pred_probs = model.predict(X_test).flatten()

# Standard Threshold (0.50)
y_pred_50 = (y_pred_probs >= 0.50).astype(int)
print("Accuracy: ", accuracy_score(y_test, y_pred_50))     # 0.6903 (69.0%)
print("Recall:   ", recall_score(y_test, y_pred_50))       # 0.5417 (54.2%)
print("ROC-AUC:  ", roc_auc_score(y_test, y_pred_probs))  # 0.6788

# Clinical Screening Threshold (0.35)
y_pred_35 = (y_pred_probs >= 0.35).astype(int)
print("Screening Recall:", recall_score(y_test, y_pred_35)) # 0.7917 (79.2%)`}</pre>
                )}

                {selectedCodeFile === 'eda_visualizations.py' && (
                  <pre>{`# Heart_Disease_Deep_Learning/src/eda_visualizations.py
# Step 3: Generates all 7 academic visualizations at 300 DPI
# 1. Target Class Distribution Bar Chart
# 2. Age Distribution Stacked Histogram + KDE
# 3. Pearson Correlation Heatmap
# 4. Outlier Boxplots (IQR) for SysBP, Glucose, Chol, BMI
# 5. Overlaid Continuous Density Curves
# 6. Scatterplot: Age vs Systolic BP with 140 mmHg line
# 7. Permutation Feature Importance Ranking`}</pre>
                )}

                {selectedCodeFile === 'app.py' && (
                  <pre>{`# Heart_Disease_Deep_Learning/app.py
# Interactive Streamlit Web Application
import streamlit as st, joblib, numpy as np, pandas as pd
import tensorflow as tf

st.title("CardioVision Deep Learning Lab")
# Sliders for 15 clinical parameters
# Live model.predict() inference
# Dynamic decision threshold slider with clinical screening guidance`}</pre>
                )}

                {selectedCodeFile === 'requirements.txt' && (
                  <pre>{`# requirements.txt
numpy>=1.24.0,<2.5.0
pandas>=2.0.0,<3.1.0
scikit-learn>=1.3.0,<2.0.0
matplotlib>=3.7.0,<4.0.0
seaborn>=0.12.0,<1.0.0
tensorflow>=2.15.0,<3.0.0
joblib>=1.3.0
streamlit>=1.30.0
scipy>=1.10.0`}</pre>
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 7: ACADEMIC REPORT & LITERATURE REVIEW
        ========================================================================= */}
        {activeTab === 'report' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-rose-400" />
                Comprehensive Academic Report & Literature Review
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Formal thesis summary, feature dictionary, methodology, and verified IEEE academic citations.
              </p>
            </div>

            {/* Feature Table (15 Features) */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-rose-400" />
                Authentic Feature Dictionary (15 Clinical Predictors + 1 Target)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                      <th className="py-2.5 px-3">#</th>
                      <th className="py-2.5 px-3">Feature Name</th>
                      <th className="py-2.5 px-3">Clinical Meaning</th>
                      <th className="py-2.5 px-3">Data Type</th>
                      <th className="py-2.5 px-3">Domain / Range</th>
                      <th className="py-2.5 px-3">Missing Count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {FEATURES_LIST.map((f, idx) => (
                      <tr key={f.name} className="hover:bg-slate-800/30">
                        <td className="py-2 px-3 font-mono text-slate-500">{idx + 1}</td>
                        <td className="py-2 px-3 font-mono font-bold text-rose-300">{f.name}</td>
                        <td className="py-2 px-3 text-slate-200">{f.description}</td>
                        <td className="py-2 px-3 text-slate-400 font-mono capitalize">{f.type}</td>
                        <td className="py-2 px-3 text-slate-400 font-mono">
                          {f.min !== undefined ? `${f.min} - ${f.max} ${f.unit || ''}` : '0 or 1'}
                        </td>
                        <td className="py-2 px-3 text-slate-400 font-mono">
                          {f.name === 'glucose' ? '388 (9.15%)' : f.name === 'education' ? '105 (2.48%)' : f.name === 'BPMeds' ? '53 (1.25%)' : f.name === 'totChol' ? '50 (1.18%)' : f.name === 'cigsPerDay' ? '29 (0.68%)' : f.name === 'BMI' ? '19 (0.45%)' : f.name === 'heartRate' ? '1 (0.02%)' : '0 (0.0%)'}
                        </td>
                      </tr>
                    ))}
                    <tr className="bg-rose-500/10 font-bold">
                      <td className="py-2 px-3 font-mono text-rose-400">Target</td>
                      <td className="py-2 px-3 font-mono text-rose-300">TenYearCHD</td>
                      <td className="py-2 px-3 text-white">10-Year Prospective Risk of Coronary Heart Disease</td>
                      <td className="py-2 px-3 font-mono">Binary</td>
                      <td className="py-2 px-3 font-mono">0 (84.8%) vs 1 (15.2%)</td>
                      <td className="py-2 px-3 font-mono">0 (0.0%)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Verified IEEE References */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-400" />
                Literature Review & Genuine References (IEEE Format)
              </h3>
              <div className="space-y-4">
                {REFERENCES_IEEE.map((ref, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2 text-xs leading-relaxed"
                  >
                    <div className="font-mono text-rose-300 font-semibold">{ref.citation}</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-slate-300 pt-2 border-t border-slate-850">
                      <div>
                        <strong className="text-slate-400">Research Objective:</strong> {ref.objective}
                      </div>
                      <div>
                        <strong className="text-slate-400">Method Used:</strong> {ref.method}
                      </div>
                      <div>
                        <strong className="text-slate-400">Main Findings:</strong> {ref.findings}
                      </div>
                      <div>
                        <strong className="text-emerald-400">Relevance to Project:</strong> {ref.relevance}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            Heart Disease Prediction Using Deep Learning with EDA & Data Visualization • Academic Project
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>TensorFlow 2.x</span>
            <span>•</span>
            <span>Keras Sequential</span>
            <span>•</span>
            <span>Scikit-Learn</span>
            <span>•</span>
            <span>Framingham Study (NHLBI)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
