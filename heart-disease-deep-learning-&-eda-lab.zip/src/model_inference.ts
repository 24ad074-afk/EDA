import { SCALER_PARAMS } from './project_data';
import modelWeightsRaw from './model_weights.json';

interface LayerData {
  name: string;
  weights: number[][][] | number[][];
}

const modelWeights = modelWeightsRaw as LayerData[];

export function predictHeartDiseaseRisk(features: Record<string, number>): {
  probability: number;
  percentage: number;
  scaledFeatures: Record<string, number>;
  riskTier: 'Low Risk' | 'Moderate Risk' | 'Elevated / High Risk';
  topRiskContributors: { feature: string; impact: string }[];
} {
  // Ordered 15 features matching model training specification
  const orderedFeatures = [
    'male', 'age', 'education', 'currentSmoker', 'cigsPerDay',
    'BPMeds', 'prevalentStroke', 'prevalentHyp', 'diabetes',
    'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose'
  ];

  // 1. Zero-leakage standardization using training parameters
  const scaledValues: number[] = [];
  const scaledRecord: Record<string, number> = {};

  for (let i = 0; i < orderedFeatures.length; i++) {
    const featName = orderedFeatures[i];
    const rawVal = features[featName] ?? 0;
    const numIdx = SCALER_PARAMS.features.indexOf(featName);

    if (numIdx !== -1) {
      const mean = SCALER_PARAMS.mean[numIdx];
      const scale = SCALER_PARAMS.scale[numIdx];
      const z = (rawVal - mean) / scale;
      scaledValues.push(z);
      scaledRecord[featName] = z;
    } else {
      scaledValues.push(rawVal);
      scaledRecord[featName] = rawVal;
    }
  }

  // 2. Layer 1: Dense 32 (W1: 15x32, b1: 32)
  const w1 = modelWeights[0].weights[0] as number[][];
  const b1 = modelWeights[0].weights[1] as unknown as number[];
  const gamma1 = modelWeights[1].weights[0] as unknown as number[];
  const beta1 = modelWeights[1].weights[1] as unknown as number[];
  const mean1 = modelWeights[1].weights[2] as unknown as number[];
  const var1 = modelWeights[1].weights[3] as unknown as number[];

  const h1: number[] = new Array(32).fill(0);
  for (let j = 0; j < 32; j++) {
    let sum = b1[j];
    for (let i = 0; i < 15; i++) {
      sum += scaledValues[i] * w1[i][j];
    }
    // Batch norm
    const bn1 = ((sum - mean1[j]) / Math.sqrt(var1[j] + 1e-3)) * gamma1[j] + beta1[j];
    // ReLU
    h1[j] = Math.max(0, bn1);
  }

  // 3. Layer 2: Dense 16 (W2: 32x16, b2: 16)
  const w2 = modelWeights[2].weights[0] as number[][];
  const b2 = modelWeights[2].weights[1] as unknown as number[];
  const gamma2 = modelWeights[3].weights[0] as unknown as number[];
  const beta2 = modelWeights[3].weights[1] as unknown as number[];
  const mean2 = modelWeights[3].weights[2] as unknown as number[];
  const var2 = modelWeights[3].weights[3] as unknown as number[];

  const h2: number[] = new Array(16).fill(0);
  for (let j = 0; j < 16; j++) {
    let sum = b2[j];
    for (let i = 0; i < 32; i++) {
      sum += h1[i] * w2[i][j];
    }
    const bn2 = ((sum - mean2[j]) / Math.sqrt(var2[j] + 1e-3)) * gamma2[j] + beta2[j];
    h2[j] = Math.max(0, bn2);
  }

  // 4. Layer 3: Dense 1 + Sigmoid
  const w3 = modelWeights[4].weights[0] as number[][];
  const b3 = modelWeights[4].weights[1] as unknown as number[];
  let z3 = b3[0];
  for (let i = 0; i < 16; i++) {
    z3 += h2[i] * w3[i][0];
  }
  const probability = 1 / (1 + Math.exp(-z3));
  const percentage = Math.round(probability * 1000) / 10;

  let riskTier: 'Low Risk' | 'Moderate Risk' | 'Elevated / High Risk' = 'Low Risk';
  if (probability >= 0.35) {
    riskTier = 'Elevated / High Risk';
  } else if (probability >= 0.20) {
    riskTier = 'Moderate Risk';
  }

  // Identify top contributing risk factors based on deviation from cohort normal
  const contributors: { feature: string; impact: string }[] = [];
  if (features.sysBP > 140) {
    contributors.push({ feature: 'Systolic Blood Pressure', impact: `High (${features.sysBP} mmHg - Stage 2 Hypertension)` });
  }
  if (features.age > 55) {
    contributors.push({ feature: 'Age Factor', impact: `Elevated (${features.age} yrs - vascular arterial stiffening)` });
  }
  if (features.currentSmoker === 1 && features.cigsPerDay > 0) {
    contributors.push({ feature: 'Tobacco Consumption', impact: `Active smoker (${features.cigsPerDay} cigs/day)` });
  }
  if (features.glucose > 125 || features.diabetes === 1) {
    contributors.push({ feature: 'Metabolic / Glucose', impact: `Hyperglycemic (${features.glucose} mg/dL)` });
  }
  if (features.totChol > 240) {
    contributors.push({ feature: 'Hypercholesterolemia', impact: `High total cholesterol (${features.totChol} mg/dL)` });
  }
  if (features.BMI > 30) {
    contributors.push({ feature: 'Obesity Index', impact: `BMI ${features.BMI.toFixed(1)} kg/m²` });
  }

  return {
    probability,
    percentage,
    scaledFeatures: scaledRecord,
    riskTier,
    topRiskContributors: contributors
  };
}
