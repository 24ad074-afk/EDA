# Framingham Heart Study Dataset Documentation

## 1. Dataset Overview & Official Provenance

* **Dataset Title:** Framingham Heart Study 10-Year Cardiovascular Disease Risk Dataset
* **Primary Origin:** Framingham Heart Study (ongoing prospective cohort study initiated in 1948 by the National Heart, Lung, and Blood Institute - NHLBI, National Institutes of Health, in collaboration with Boston University)
* **Official Repository & Access:**
  - NHLBI BioData Catalyst / BioLINCC: [https://biolincc.nhlbi.nih.gov/studies/framingham/](https://biolincc.nhlbi.nih.gov/studies/framingham/)
  - Public Machine Learning Benchmark (Kaggle): [https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression](https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression)
* **Total Instances (Rows):** 4,240 patient records
* **Total Fields (Columns):** 16 columns (15 clinical input features + 1 binary ground-truth target)
* **Task Type:** Supervised Binary Classification

---

## 2. Target Variable Specification

* **Target Variable:** `TenYearCHD`
* **Definition:** 10-year prospective risk of coronary heart disease (CHD), encompassing myocardial infarction (heart attack) and fatal or non-fatal coronary death.
* **Class 0 (Negative):** No CHD diagnosed within the 10-year follow-up period — **3,596 patients (84.8%)**
* **Class 1 (Positive):** CHD event confirmed within the 10-year follow-up period — **644 patients (15.2%)**
* **Class Imbalance Ratio:** ~5.58 : 1 (reflects authentic epidemiological disease prevalence in general populations).

---

## 3. Comprehensive Feature Dictionary (15 Input Features)

| Feature # | Column Name | Clinical Semantic Meaning | Data Type | Measurement Unit / Valid Domain | Clinical Relevance |
|---|---|---|---|---|---|
| **1** | `male` | Biological Sex at Birth | Nominal Binary | 0 = Female, 1 = Male | Hormonal and vascular differences affect early onset risk |
| **2** | `age` | Patient Chronological Age | Continuous | 32 to 70 Years | Primary non-modifiable cardiovascular risk factor |
| **3** | `education` | Highest Level of Education | Ordinal Categorical | 1 = Some HS, 2 = HS/GED, 3 = Some College, 4 = College Grad | Socioeconomic indicator impacting health literacy & access |
| **4** | `currentSmoker` | Active Tobacco Smoking Status | Nominal Binary | 0 = Non-Smoker, 1 = Active Smoker | Endothelial damage and plaque instability accelerator |
| **5** | `cigsPerDay` | Daily Tobacco Cigarette Consumption | Discrete Numerical | 0 to 70 cigarettes/day | Dose-response relationship with vascular constriction |
| **6** | `BPMeds` | Use of Anti-Hypertensive Medication | Nominal Binary | 0 = Not on BP Meds, 1 = Prescribed BP Meds | Indicator of established clinical hypertension severity |
| **7** | `prevalentStroke` | History of Cerebrovascular Stroke | Nominal Binary | 0 = No history, 1 = Previous stroke event | Direct marker of systemic arterial and vascular disease |
| **8** | `prevalentHyp` | Prevalent Hypertension Diagnosis | Nominal Binary | 0 = Normotensive, 1 = Hypertensive | Chronic vascular shearing leading to ventricular hypertrophy |
| **9** | `diabetes` | Diagnosed Clinical Diabetes Mellitus | Nominal Binary | 0 = Non-diabetic, 1 = Diabetic | Hyperglycemia accelerating micro/macro-vascular damage |
| **10** | `totChol` | Total Serum Cholesterol | Continuous | 107 to 696 mg/dL | Biomarker for atherogenic low-density lipoprotein build-up |
| **11** | `sysBP` | Systolic Blood Pressure | Continuous | 83.5 to 295.0 mmHg | Peak arterial pressure during left ventricular contraction |
| **12** | `diaBP` | Diastolic Blood Pressure | Continuous | 48.0 to 142.5 mmHg | Minimum arterial pressure during ventricular filling phase |
| **13** | `BMI` | Body Mass Index ($\text{weight}/\text{height}^2$) | Continuous | 15.54 to 56.80 $\text{kg/m}^2$ | Adiposity marker linked to metabolic syndrome |
| **14** | `heartRate` | Resting Heart Rate | Continuous | 44 to 143 beats per minute | Autonomic nervous balance and cardiovascular workload |
| **15** | `glucose` | Fasting Blood Plasma Glucose | Continuous | 40 to 394 mg/dL | Diagnostic biomarker for impaired metabolic regulation |

---

## 4. Missing Value Profile & Clinical Imputation Strategy

The raw dataset contains missing entries across 7 columns:
* `glucose`: 388 missing entries (9.15%)
* `education`: 105 missing entries (2.48%)
* `BPMeds`: 53 missing entries (1.25%)
* `totChol`: 50 missing entries (1.18%)
* `cigsPerDay`: 29 missing entries (0.68%)
* `BMI`: 19 missing entries (0.45%)
* `heartRate`: 1 missing entry (0.02%)

### Imputation Rationale:
1. **`cigsPerDay`**: Conditional clinical logic: Patients where `currentSmoker == 0` are assigned `0`; active smokers with missing counts are imputed with the median smoking rate (9 cigarettes/day).
2. **`BPMeds` & `education`**: Categorical features are imputed with their statistical mode (`BPMeds=0`, `education=1`).
3. **Continuous Biometric Variables (`totChol`, `BMI`, `heartRate`, `glucose`)**: Imputed using the median of the distribution to avoid skew from extreme physiological outliers.

---

## 5. Download & Placement Instructions

### Option A: Automatic Loading (Default)
The repository includes `framingham.csv` directly inside `Heart_Disease_Deep_Learning/data/framingham.csv`. Scripts automatically locate it without manual steps.

### Option B: Manual Download from Kaggle
1. Navigate to: [https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression](https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression)
2. Click **Download (58 kB)**.
3. Extract the downloaded ZIP archive.
4. Rename the extracted file to `framingham.csv` and place it in the `Heart_Disease_Deep_Learning/data/` folder.
