"""
app.py
======
Interactive Streamlit Web Application
Project: Heart Disease Prediction Using Deep Learning with EDA & Visualization
Dataset: Framingham Heart Study

To run locally:
$ streamlit run app.py
"""

import os
import json
import numpy as np
import pandas as pd
import streamlit as st
import joblib

# Page configuration
st.set_page_config(
    page_title="CardioVision DL - Heart Disease Prediction",
    page_icon="❤️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for clinical dashboard styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 800;
        color: #e11d48;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #64748b;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
    }
    .alert-banner {
        background-color: #fff1f2;
        border-left: 4px solid #e11d48;
        padding: 0.8rem 1.2rem;
        border-radius: 4px;
        color: #9f1239;
        font-size: 0.9rem;
        margin-bottom: 1.5rem;
    }
</style>
""", unsafe_allow_html=True)

# File paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs") if os.path.exists(os.path.join(BASE_DIR, "outputs")) else os.path.join(BASE_DIR, "Heart_Disease_Deep_Learning", "outputs")
MODEL_PATH = os.path.join(OUTPUTS_DIR, "heart_disease_mlp_model.keras")
SCALER_PATH = os.path.join(OUTPUTS_DIR, "scaler.joblib")
METRICS_PATH = os.path.join(OUTPUTS_DIR, "evaluation_metrics.json")
EDA_DIR = os.path.join(OUTPUTS_DIR, "eda_visualizations")
EVAL_DIR = os.path.join(OUTPUTS_DIR, "evaluation_visualizations")

@st.cache_resource
def load_model_and_scaler():
    try:
        import tensorflow as tf
        model = tf.keras.models.load_model(MODEL_PATH)
    except Exception as e:
        model = None
    scaler = joblib.load(SCALER_PATH) if os.path.exists(SCALER_PATH) else None
    return model, scaler

@st.cache_data
def load_metrics():
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH, "r") as f:
            return json.load(f)
    return None

model, scaler = load_model_and_scaler()
metrics = load_metrics()

# Header & Disclaimer
st.markdown('<div class="main-header">❤️ CardioVision: Deep Learning Heart Disease Predictor</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Multilayer Perceptron (MLP) Neural Network for 10-Year Coronary Heart Disease Risk Assessment | Framingham Cohort Benchmark</div>', unsafe_allow_html=True)

st.markdown("""
<div class="alert-banner">
    ⚠️ <strong>ACADEMIC DISCLAIMER:</strong> This software is an educational prototype developed for data science and deep learning research. It is <strong>NOT</strong> clinically validated, diagnostic medical software. Do not make medical decisions based on its output.
</div>
""", unsafe_allow_html=True)

# Navigation tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🧮 Patient Risk Assessment",
    "📊 Exploratory Data Analysis (EDA)",
    "🧠 Deep Learning Architecture",
    "📈 Model Evaluation & ROC",
    "📚 Seven Stages of Visualization"
])

# -------------------------------------------------------------------------------------------------
# TAB 1: PATIENT RISK ASSESSMENT CALCULATOR
# -------------------------------------------------------------------------------------------------
with tab1:
    st.subheader("Interactive Patient Clinical Profile")
    st.write("Input patient demographics, behavioral risk factors, and biometric examination metrics to predict 10-year coronary heart disease (CHD) risk.")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("#### Demographics & Lifestyle")
        male = st.selectbox("Biological Sex", [0, 1], format_func=lambda x: "Male" if x == 1 else "Female")
        age = st.slider("Age (Years)", min_value=30, max_value=80, value=52)
        education = st.selectbox("Education Level", [1, 2, 3, 4], 
                                 format_func=lambda x: {1: "1: Some High School", 2: "2: High School / GED", 3: "3: Some College", 4: "4: College Graduate"}[x])
        currentSmoker = st.selectbox("Current Tobacco Smoker?", [0, 1], format_func=lambda x: "Yes" if x == 1 else "No")
        cigsPerDay = st.slider("Cigarettes per Day", min_value=0, max_value=60, value=15 if currentSmoker else 0)
        if currentSmoker == 0:
            cigsPerDay = 0

    with col2:
        st.markdown("#### Medical History & Conditions")
        BPMeds = st.selectbox("On Blood Pressure Medication?", [0, 1], format_func=lambda x: "Yes" if x == 1 else "No")
        prevalentStroke = st.selectbox("History of Prior Stroke?", [0, 1], format_func=lambda x: "Yes" if x == 1 else "No")
        prevalentHyp = st.selectbox("Prevalent Hypertension?", [0, 1], format_func=lambda x: "Yes" if x == 1 else "No")
        diabetes = st.selectbox("Diagnosed Diabetes Mellitus?", [0, 1], format_func=lambda x: "Yes" if x == 1 else "No")
        heartRate = st.slider("Resting Heart Rate (BPM)", min_value=40, max_value=140, value=75)

    with col3:
        st.markdown("#### Physiological & Laboratory Biomarkers")
        totChol = st.slider("Total Serum Cholesterol (mg/dL)", min_value=100, max_value=450, value=236)
        sysBP = st.slider("Systolic Blood Pressure (mmHg)", min_value=80, max_value=240, value=132)
        diaBP = st.slider("Diastolic Blood Pressure (mmHg)", min_value=50, max_value=140, value=82)
        BMI = st.slider("Body Mass Index (BMI in kg/m²)", min_value=15.0, max_value=50.0, value=25.8, step=0.1)
        glucose = st.slider("Fasting Blood Glucose (mg/dL)", min_value=50, max_value=300, value=82)

    st.markdown("---")
    threshold_col, predict_col = st.columns([1, 2])
    with threshold_col:
        threshold = st.slider("Decision Threshold (Classification Cutoff)", min_value=0.10, max_value=0.90, value=0.35, step=0.05,
                              help="Default is 0.50. For clinical screening, a lower threshold (~0.35) increases sensitivity, catching more at-risk individuals.")
    
    with predict_col:
        st.write("")
        st.write("")
        predict_btn = st.button("🚀 Compute 10-Year Cardiovascular Disease Risk", use_container_width=True, type="primary")

    if predict_btn and model is not None and scaler is not None:
        # Construct feature vector matching exact training order
        features_dict = {
            'male': male, 'age': age, 'education': education, 'currentSmoker': currentSmoker,
            'cigsPerDay': cigsPerDay, 'BPMeds': BPMeds, 'prevalentStroke': prevalentStroke,
            'prevalentHyp': prevalentHyp, 'diabetes': diabetes, 'totChol': totChol,
            'sysBP': sysBP, 'diaBP': diaBP, 'BMI': BMI, 'heartRate': heartRate, 'glucose': glucose
        }
        df_input = pd.DataFrame([features_dict])
        
        # Scale continuous features using the training scaler
        num_cols = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
        df_scaled = df_input.copy()
        df_scaled[num_cols] = scaler.transform(df_input[num_cols])
        
        # Predict probability
        input_array = np.array(df_scaled, dtype=np.float32)
        raw_prob = float(model.predict(input_array, verbose=0)[0][0])
        predicted_class = 1 if raw_prob >= threshold else 0

        st.markdown("### Risk Prediction Results")
        res_col1, res_col2, res_col3 = st.columns(3)
        with res_col1:
            st.metric("Predicted 10-Year CHD Probability", f"{raw_prob * 100:.1f}%")
        with res_col2:
            st.metric("Classification Threshold Applied", f"{threshold:.2f}")
        with res_col3:
            if predicted_class == 1:
                st.error("🚨 HIGH RISK: Positive for 10-Year CHD")
            else:
                st.success("✅ LOW RISK: Negative for 10-Year CHD")

        # Risk stratification bar
        st.progress(raw_prob)
        if raw_prob < 0.20:
            st.info("💡 **Clinical Interpretation:** Patient falls into the low baseline risk tier. Maintain routine lifestyle guidance.")
        elif raw_prob < 0.40:
            st.warning("⚠️ **Clinical Interpretation:** Moderate borderline risk tier. Elevated blood pressure or age observed.")
        else:
            st.error("🛑 **Clinical Interpretation:** High risk tier. Substantial vascular risk factors detected across systolic blood pressure, smoking, and metabolic markers.")

# -------------------------------------------------------------------------------------------------
# TAB 2: EXPLORATORY DATA ANALYSIS (EDA)
# -------------------------------------------------------------------------------------------------
with tab2:
    st.subheader("Exploratory Data Analysis: Framingham Heart Study")
    st.write("Browse the 7 core academic visualizations generated from the authentic 4,240-patient cohort.")
    
    eda_options = [
        ("01_target_distribution.png", "1. Target Class Distribution", "Visualizes the 85:15 class imbalance between negative and positive CHD patients."),
        ("02_age_distribution.png", "2. Age Distribution by Outcome", "Shows age progression and higher proportion of heart disease in older age brackets."),
        ("03_correlation_heatmap.png", "3. Pearson Correlation Heatmap", "Highlights collinearity between systolic and diastolic BP, and correlations with age and outcome."),
        ("04_outlier_boxplots.png", "4. Clinical Outlier Boxplots (IQR)", "Displays physiological extremes across BP, cholesterol, glucose, and BMI retained for medical validity."),
        ("05_feature_distributions.png", "5. Continuous Feature Densities (KDE)", "Comparative kernel density curves illustrating right-skew in blood glucose and blood pressure."),
        ("06_age_vs_sysbp_scatterplot.png", "6. Scatterplot: Age vs Systolic BP", "Demonstrates the compounding effect of aging and Stage 2 hypertension on heart disease."),
        ("07_feature_importance.png", "7. Permutation Feature Importance", "Ranks the top influential predictors: Age, Systolic BP, Glucose, Cigs/Day, and Total Cholesterol.")
    ]
    
    selected_eda = st.selectbox("Select Visual Exploration:", eda_options, format_func=lambda x: x[1])
    img_path = os.path.join(EDA_DIR, selected_eda[0])
    
    if os.path.exists(img_path):
        st.image(img_path, caption=selected_eda[1], use_container_width=True)
        st.info(f"**Analytical Finding:** {selected_eda[2]}")
    else:
        st.warning(f"Visualization {selected_eda[0]} not found at {img_path}.")

# -------------------------------------------------------------------------------------------------
# TAB 3: DEEP LEARNING ARCHITECTURE
# -------------------------------------------------------------------------------------------------
with tab3:
    st.subheader("Multilayer Perceptron (MLP) Deep Learning Architecture")
    st.markdown("""
    ### Why Multilayer Perceptron for Clinical Tabular Data?
    - **Dense Semantic Representation:** Unlike image pixels or text sequences, clinical attributes have distinct physical dimensions (years, mmHg, mg/dL).
    - **Non-Linear Synergy Learning:** MLPs model complex physiological interactions (e.g., how the intersection of smoking and hypertension multiplies coronary risk beyond independent addition).
    
    ### Architecture Specifications:
    - **Input Layer:** 15 neurons (matching preprocessed features)
    - **Hidden Layer 1:** 32 Dense Units + ReLU + Batch Normalization + Dropout (0.10) + L2 Regularization ($10^{-4}$)
    - **Hidden Layer 2:** 16 Dense Units + ReLU + Batch Normalization + Dropout (0.10) + L2 Regularization ($10^{-4}$)
    - **Output Layer:** 1 Dense Unit + Sigmoid Activation ($P \in [0.0, 1.0]$)
    - **Loss Function:** Binary Cross-Entropy
    - **Optimizer:** Adam ($\alpha = 0.001$)
    - **Imbalance Mitigation:** Balanced Class Weighting ($w_0 = 0.59, w_1 = 3.29$)
    - **Regularization:** EarlyStopping monitoring validation ROC-AUC with patience = 15
    """)

# -------------------------------------------------------------------------------------------------
# TAB 4: MODEL EVALUATION & ROC
# -------------------------------------------------------------------------------------------------
with tab4:
    st.subheader("Model Evaluation on Unseen Test Cohort (N = 636)")
    if metrics:
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("ROC-AUC Score", f"{metrics['threshold_default']['roc_auc']:.3f}")
        m2.metric("Accuracy (Std 0.50)", f"{metrics['threshold_default']['accuracy']*100:.1f}%")
        m3.metric("Recall (Std 0.50)", f"{metrics['threshold_default']['recall']*100:.1f}%")
        m4.metric("Recall (Screening 0.35)", f"{metrics['threshold_clinical_screening']['recall']*100:.1f}%")
        m5.metric("F1-Score", f"{metrics['threshold_default']['f1_score']:.3f}")
    
    eval_col1, eval_col2 = st.columns(2)
    with eval_col1:
        loss_img = os.path.join(EVAL_DIR, "01_loss_vs_epoch.png")
        if os.path.exists(loss_img):
            st.image(loss_img, caption="Training vs Validation Loss", use_container_width=True)
        cm_img = os.path.join(EVAL_DIR, "03_confusion_matrix.png")
        if os.path.exists(cm_img):
            st.image(cm_img, caption="Test Confusion Matrix (Threshold 0.50)", use_container_width=True)

    with eval_col2:
        acc_img = os.path.join(EVAL_DIR, "02_accuracy_vs_epoch.png")
        if os.path.exists(acc_img):
            st.image(acc_img, caption="Training vs Validation Accuracy", use_container_width=True)
        roc_img = os.path.join(EVAL_DIR, "04_roc_curve.png")
        if os.path.exists(roc_img):
            st.image(roc_img, caption="Receiver Operating Characteristic (ROC) Curve", use_container_width=True)

# -------------------------------------------------------------------------------------------------
# TAB 5: SEVEN STAGES OF VISUALIZATION
# -------------------------------------------------------------------------------------------------
with tab5:
    st.subheader("The Seven Stages of Data Visualization (Ben Fry Framework)")
    st.markdown("""
    This project strictly maps the academic 7-stage visualization pipeline to the Framingham dataset:

    1. **Acquire:** Obtain the clinical dataset (Framingham Heart Study, N=4,240 records across 16 fields).
    2. **Parse:** Structure raw records into tabular formats, assigning data types (binary flags, continuous biometrics, categorical education).
    3. **Filter:** Remove uninformative noise and handle missing values through domain-specific imputation (median for continuous, mode for categorical, conditional logic for smokers).
    4. **Mine:** Apply statistical profiling (IQR outlier detection, Pearson correlation matrix, class ratio analysis).
    5. **Represent:** Select foundational visual encodings (stacked histograms for demographics, diverging heatmaps for correlation, boxplots for dispersion).
    6. **Refine:** Polish visual clarity by adding medical thresholds (e.g., 140 mmHg hypertension line, annotated percentages on class distributions, standard color palettes).
    7. **Interact:** Provide dynamic interactive controls (threshold sliders, feature input controls, real-time risk classification feedback).
    """)

st.markdown("---")
st.caption("Heart Disease Prediction Deep Learning & Data Visualization Project | Open-Source Academic Artifact")
