# Academic Project Report
# Heart Disease Prediction Using Deep Learning with Exploratory Data Analysis and Data Visualization

**Course / Subject:** Deep Learning & Data Visualization  
**Project Title:** Heart Disease Prediction Using Deep Learning with Exploratory Data Analysis and Data Visualization  
**Dataset:** Framingham Heart Study (4,240 Patient Cohort, 15 Clinical Input Features, 1 Binary Target)  
**Methodology:** Multilayer Perceptron (MLP) Neural Network, Zero-Leakage Preprocessing Pipeline, Ben Fry 7-Stage Visualization Framework  
**Author:** AI Studio Research Engineering Lab  
**Date:** Academic Term 2026  

---

## Executive Summary

Cardiovascular diseases (CVDs) remain the leading cause of global mortality, accounting for approximately 17.9 million deaths annually according to the World Health Organization. Early non-invasive detection of individuals at elevated risk of developing Coronary Heart Disease (CHD) enables targeted clinical lifestyle modifications and pharmacological interventions.

This project delivers an end-to-end deep learning and data visualization framework trained on the authentic **Framingham Heart Study** dataset (4,240 patient records, 15 input features). We implemented a strict **zero-leakage data preprocessing pipeline**, applied **Ben Fry's Seven Stages of Data Visualization** to uncover physiological risk correlations, developed a **Multilayer Perceptron (MLP)** neural network with Batch Normalization and Dropout, executed hyperparameter tuning with Early Stopping, and performed rigorous unbiased testing on 636 unseen patient records.

---

## 1. Step 1: Dataset Selection and Structural Verification

### 1.1 Dataset Provenance & Official Source
* **Origin:** The Framingham Heart Study, an ongoing prospective epidemiological cohort study initiated in 1948 by the National Heart, Lung, and Blood Institute (NHLBI) and Boston University.
* **Official Access:** 
  - National Institutes of Health (NIH) BioLINCC: [https://biolincc.nhlbi.nih.gov/studies/framingham/](https://biolincc.nhlbi.nih.gov/studies/framingham/)
  - Kaggle Public Benchmark: [https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression](https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression)
* **Cohort Dimensions:** Exactly 4,240 patient records and 16 fields (15 input features + 1 binary target).
* **Target Variable:** `TenYearCHD` (binary: 0 = No CHD event within 10 years; 1 = Positive CHD event).

### 1.2 Feature Verification Table (15 Input Features)
The dataset satisfies the project requirement of containing at least 15 features without fabricating synthetic attributes:

| # | Column Name | Clinical Semantic Meaning | Type | Range / Domain | Missing Count |
|---|---|---|---|---|---|
| 1 | `male` | Biological sex at birth | Binary | 0 = Female, 1 = Male | 0 (0.0%) |
| 2 | `age` | Chronological age | Continuous | 32 to 70 years | 0 (0.0%) |
| 3 | `education` | Highest educational level | Ordinal | 1: Some HS, 2: HS, 3: College, 4: Grad | 105 (2.48%) |
| 4 | `currentSmoker` | Active tobacco smoker | Binary | 0 = No, 1 = Yes | 0 (0.0%) |
| 5 | `cigsPerDay` | Cigarettes smoked per day | Continuous | 0 to 70 cigs/day | 29 (0.68%) |
| 6 | `BPMeds` | Use of anti-hypertensive drugs | Binary | 0 = No, 1 = Yes | 53 (1.25%) |
| 7 | `prevalentStroke` | History of stroke | Binary | 0 = No, 1 = Yes | 0 (0.0%) |
| 8 | `prevalentHyp` | Prevalent hypertension | Binary | 0 = No, 1 = Yes | 0 (0.0%) |
| 9 | `diabetes` | Diagnosed diabetes | Binary | 0 = No, 1 = Yes | 0 (0.0%) |
| 10 | `totChol` | Total serum cholesterol | Continuous | 107 to 696 mg/dL | 50 (1.18%) |
| 11 | `sysBP` | Systolic blood pressure | Continuous | 83.5 to 295.0 mmHg | 0 (0.0%) |
| 12 | `diaBP` | Diastolic blood pressure | Continuous | 48.0 to 142.5 mmHg | 0 (0.0%) |
| 13 | `BMI` | Body mass index | Continuous | 15.54 to 56.80 kg/m² | 19 (0.45%) |
| 14 | `heartRate` | Resting heart rate | Continuous | 44 to 143 bpm | 1 (0.02%) |
| 15 | `glucose` | Fasting blood glucose | Continuous | 40 to 394 mg/dL | 388 (9.15%) |

---

## 2. Step 2: Data Understanding & Preprocessing Pipeline

### 2.1 Missing Value Treatment with Clinical Rules
1. **`cigsPerDay`:** Rather than applying blind global imputation, we enforced clinical consistency: if `currentSmoker == 0`, `cigsPerDay` was set to `0`. If `currentSmoker == 1`, missing values were imputed using the median of active smokers (9 cigarettes/day).
2. **`BPMeds` & `education`:** Categorical attributes were imputed using the statistical mode (`BPMeds = 0`, `education = 1`).
3. **Continuous Physiological Metrics (`totChol`, `BMI`, `heartRate`, `glucose`):** Imputed with the feature median to prevent distortion caused by right-skewed physiological anomalies.

### 2.2 Outlier Analysis (IQR Method) & Medical Justification
The Interquartile Range (IQR = $Q_3 - Q_1$) method detected mathematical outliers:
- `sysBP`: 126 records above 170.0 mmHg ($Q_3 + 1.5 \times \text{IQR}$)
- `glucose`: 193 records above 109.5 mg/dL
- `totChol`: 56 records above 330.5 mg/dL

**Clinical Rationale for Retention:** In clinical medicine, extreme systolic BP (e.g. 210 mmHg) or blood glucose (e.g. 260 mg/dL) represents acute hypertension and uncontrolled diabetes. These are not measurement artifacts; they are the primary biological drivers of coronary plaque rupture. Removing them would sanitize the data and blind the model to critical clinical emergency signals.

### 2.3 Stratified Splitting and Data Leakage Prevention
To guarantee honest evaluation:
1. **Stratified Split:** Split into Training (70%, N=2,968), Validation (15%, N=636), and Testing (15%, N=636) preserving the 85:15 target class proportion across all subsets.
2. **Leakage Prevention:** `StandardScaler` was strictly fit on `X_train` only (`scaler.fit(X_train)`). The validation and test sets were transformed using the frozen training parameters (`scaler.transform(X_val)`).

---

## 3. Step 3: Exploratory Data Analysis & Visualization Workflow

### 3.1 Mapping to Ben Fry's Seven Stages of Data Visualization
1. **Acquire:** Downloaded the official Framingham cohort (4,240 records).
2. **Parse:** Structured data into numeric and binary types with appropriate schema constraints.
3. **Filter:** Imputed missing values and isolated continuous versus categorical subsets.
4. **Mine:** Extracted Pearson correlation coefficients, class distributions, and permutation importance scores.
5. **Represent:** Formatted representations (histograms, KDE curves, heatmaps, boxplots, scatterplots).
6. **Refine:** Annotated clinical thresholds (hypertension cutoff at 140 mmHg), percentages on bars, and publication-ready color contrasts.
7. **Interact:** Provided an interactive Streamlit and web-based dashboard allowing dynamic decision threshold adjustment and real-time inference.

### 3.2 Visual Analysis & Key Insights from the Seven Figures

1. **Target Class Distribution (`01_target_distribution.png`):**
   - *Finding:* Class 0 = 3,596 (84.8%), Class 1 = 644 (15.2%).
   - *Implication:* Extreme imbalance requiring class-weighted loss functions to avoid trivial majority-class prediction.
2. **Age Distribution by Outcome (`02_age_distribution.png`):**
   - *Finding:* Mean age for negative patients is 48.8 years; mean age for positive CHD patients is 54.1 years. Heart disease incidence climbs sharply after age 50.
3. **Pearson Correlation Heatmap (`03_correlation_heatmap.png`):**
   - *Finding:* High collinearity between `sysBP` and `diaBP` ($r = 0.78$) and between `diabetes` and `glucose` ($r = 0.62$). Moderate positive correlations between age, systolic BP, and `TenYearCHD`.
4. **Clinical Outlier Boxplots (`04_outlier_boxplots.png`):**
   - *Finding:* The interquartile box and median for systolic BP and blood glucose are visibly elevated in CHD-positive patients compared to negative controls.
5. **Kernel Density Estimates (`05_feature_distributions.png`):**
   - *Finding:* Blood glucose exhibits a long right tail extending past 300 mg/dL among diabetic CHD patients.
6. **Age vs. Systolic Blood Pressure Scatterplot (`06_age_vs_sysbp_scatterplot.png`):**
   - *Finding:* Patients with both advancing age (> 55) and systolic BP exceeding Stage 2 hypertension (140 mmHg) show concentrated clustering of positive CHD outcomes.
7. **Permutation Feature Importance (`07_feature_importance.png`):**
   - *Finding:* The five most influential features in order are: `sysBP` (Systolic BP), `age`, `glucose`, `cigsPerDay`, and `totChol`.

---

## 4. Step 4: Deep Learning Model Architecture & Hyperparameter Tuning

### 4.1 Justification for Multilayer Perceptron (MLP)
Tabular clinical records lack translational invariance (unlike computer vision grids) and sequential syntax (unlike NLP). MLPs with fully-connected layers, batch normalization, and dropout are mathematically well-suited to learn non-linear polynomial cross-features between clinical variables while maintaining minimal parameter footprints.

### 4.2 Hyperparameter Tuning Comparison
We evaluated three candidate architectures using 70% training and 15% validation:

| Configuration | Hidden Units | Dropout | Learning Rate | Early Stopping Epoch | Val Loss | Val Recall | Val ROC-AUC |
|---|---|---|---|---|---|---|---|
| **Config A (Compact)** | **[32, 16]** | **0.10** | **0.0010** | **28** | **0.6165** | **60.82%** | **0.7113 (Champion)** |
| Config B (Standard Deep) | [64, 32] | 0.20 | 0.0010 | 21 | 0.6131 | 59.79% | 0.6899 |
| Config C (Regularized Deep)| [64, 32, 16] | 0.30 | 0.0005 | 23 | 0.6524 | 68.04% | 0.7036 |

**Selection Rationale:** Config A achieved the highest validation ROC-AUC (0.7113). Excessive network depth on clinical tabular data of 4,000 samples induces variance without improving discriminability.

### 4.3 Champion Model Specifications
- **Input Layer:** 15 input nodes
- **Hidden Layer 1:** 32 Dense Units + ReLU + Batch Normalization + Dropout (0.10) + L2 Regularization ($10^{-4}$)
- **Hidden Layer 2:** 16 Dense Units + ReLU + Batch Normalization + Dropout (0.10) + L2 Regularization ($10^{-4}$)
- **Output Layer:** 1 Dense Unit + Sigmoid Activation ($P(\text{CHD}=1 | X) \in [0, 1]$)
- **Loss:** Binary Cross-Entropy with balanced class weighting ($w_0 = 0.590, w_1 = 3.290$)
- **Optimizer:** Adam ($\alpha = 0.001$)

---

## 5. Step 5: Model Evaluation on Unseen Test Dataset (N=636)

The champion model was evaluated once on the isolated test partition (540 negative cases, 96 positive cases).

### 5.1 Official Evaluation Metrics Table

| Metric | Default Decision Threshold ($\tau = 0.50$) | Clinical Screening Threshold ($\tau = 0.35$) |
|---|---|---|
| **Accuracy** | **69.03%** | 51.10% |
| **Precision** | **25.37%** | 20.71% |
| **Recall (Sensitivity)** | **54.17%** | **79.17%** |
| **Specificity** | **71.67%** | 46.11% |
| **F1-Score** | **0.3455** | 0.3283 |
| **ROC-AUC Score** | **0.6788** | **0.6788** |
| **True Negatives (TN)** | 387 | 249 |
| **False Positives (FP)** | 153 | 291 |
| **False Negatives (FN)** | 44 | **20** |
| **True Positives (TP)** | 52 | **76** |

### 5.2 Discussion of Clinical Threshold Implications
In standard machine learning benchmarks, a 0.50 threshold is conventional. However, in medical epidemiology, **a False Negative (FN) means an at-risk individual is falsely diagnosed as healthy**, leading to untreated coronary atherosclerosis and potential fatal cardiac events. Conversely, a **False Positive (FP) merely triggers secondary follow-up** (e.g. an ECG or lipid panel). 

By adjusting the threshold to **$\tau = 0.35$**, the model captures **79.17% of all true positive heart disease cases** (reducing false negatives from 44 down to 20).

---

## 6. Step 6: Conclusion, Limitations & Future Scope

### 6.1 Academic Conclusion
1. The project successfully demonstrates an end-to-end deep learning workflow on authentic medical cohort data.
2. Exploratory Data Analysis verified that systolic blood pressure, patient age, fasting blood glucose, and cigarette consumption are the primary drivers of 10-year coronary heart disease.
3. Class-weighted Multilayer Perceptrons achieve competitive discriminative capability ($\text{AUC} \approx 0.68 - 0.71$) while remaining light enough to execute on consumer hardware.

### 6.2 Limitations
1. **Demographic Homogeneity:** The Framingham cohort consists primarily of Caucasian residents of Massachusetts, limiting generalization across diverse global ethnicities.
2. **Missing Longitudinal Markers:** Does not include modern high-sensitivity cardiac troponin, coronary artery calcium (CAC) scoring, or genomic polygenic risk scores.
3. **Class Imbalance:** Only 15.2% of patients experienced a CHD event, constraining precision scores.

### 6.3 Future Scope
1. Implement gradient boosted decision trees (XGBoost, LightGBM, CatBoost) to benchmark against deep learning tabular models.
2. Integrate Explainable AI (SHAP / TreeSHAP) to generate individual patient local explanation waterfalls.
3. Explore self-supervised tabular models such as TabNet or Saint.

---

## 7. Step 7: Literature Review & References (IEEE Format)

[1] T. R. Dawber, G. F. Meadors, and F. E. Moore, "Epidemiological approaches to heart disease: the Framingham Study," *American Journal of Public Health*, vol. 41, no. 3, pp. 279-286, Mar. 1951. DOI: 10.2105/ajph.41.3.279.  
* **Objective:** Establish the initial prospective methodology for tracking cardiovascular risk factors over multi-decade follow-ups.
* **Method:** Cohort surveillance of 5,209 adult residents in Framingham, MA.
* **Findings:** First clinical trial to demonstrate conclusive links between hypertension, hypercholesterolemia, and coronary atherosclerosis.
* **Relevance:** Establishes the clinical and historical validity of the dataset utilized in this project.

[2] P. W. Wilson, R. B. D'Agostino, D. Levy, A. M. Belanger, H. Silbershatz, and W. B. Kannel, "Prediction of coronary heart disease using risk factor categories," *Circulation*, vol. 97, no. 18, pp. 1837-1847, May 1998. DOI: 10.1161/01.cir.97.18.1837.  
* **Objective:** Develop standard categorical score sheets for 10-year coronary disease risk calculation.
* **Method:** Cox proportional hazards regression modeling on 2,489 men and 2,856 women.
* **Findings:** Quantified the independent and synergistic predictive weights of age, blood pressure, smoking, and diabetes.
* **Relevance:** Serves as the clinical baseline for the feature set and target variable (`TenYearCHD`) implemented in this deep learning architecture.

[3] L. Grinsztajn, E. Oyallon, and G. Varoquaux, "Why do tree-based models still outperform deep learning on typical tabular data?" in *Advances in Neural Information Processing Systems (NeurIPS)*, vol. 35, pp. 507-520, Dec. 2022.  
* **Objective:** Benchmark deep learning architectures against decision tree ensembles across 45 medium-sized tabular datasets.
* **Method:** Comparative empirical evaluation of ResNet, MLP, Saint, XGBoost, and Random Forests.
* **Findings:** MLPs require careful regularization (batch normalization, dropout, early stopping) to prevent overfitting on un-rotated coordinate subspaces.
* **Relevance:** Guided our hyperparameter tuning decision to select a compact 2-layer MLP with early stopping rather than an overly deep network.

[4] M. Abadi et al., "TensorFlow: A system for large-scale machine learning," in *12th USENIX Symposium on Operating Systems Design and Implementation (OSDI)*, pp. 265-283, Nov. 2016.  
* **Objective:** Present the design and execution architecture of TensorFlow.
* **Method:** Dataflow computational graphs with automatic differentiation.
* **Findings:** Demonstrated unified CPU/GPU execution for deep learning models.
* **Relevance:** Primary deep learning framework utilized for model construction and training.

[5] F. Pedregosa et al., "Scikit-learn: Machine Learning in Python," *Journal of Machine Learning Research (JMLR)*, vol. 12, pp. 2825-2830, Oct. 2011.  
* **Objective:** Provide robust, efficient tools for predictive data analysis.
* **Method:** Consistent object-oriented API in Python for preprocessing, model evaluation, and cross-validation.
* **Findings:** Established open-source industry standard for feature scaling, permutation importance, and metric calculations.
* **Relevance:** Used for zero-leakage `StandardScaler`, stratified splitting, and confusion matrix evaluation.
