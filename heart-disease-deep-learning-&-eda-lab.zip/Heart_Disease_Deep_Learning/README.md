# Heart Disease Prediction Using Deep Learning with EDA & Data Visualization

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![TensorFlow 2.x](https://img.shields.io/badge/TensorFlow-2.x-orange.svg)](https://tensorflow.org)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.3+-green.svg)](https://scikit-learn.org)
[![Academic Project](https://img.shields.io/badge/Academic-Capstone-rose.svg)](https://github.com)

A complete, beginner-friendly academic project that satisfies all requirements for Deep Learning and Data Visualization curriculum assignments. It includes an authentic 4,240-patient cohort analysis, a 7-stage visualization pipeline, a Multilayer Perceptron (MLP) neural network, unbiased test metrics, a Streamlit web app, and an interactive web dashboard.

---

## 🗂 Project Structure

```text
Heart_Disease_Deep_Learning/
│
├── data/
│   ├── README.md               # Dataset documentation & feature dictionary
│   └── framingham.csv          # Authentic 4,240-row Framingham cohort dataset
│
├── notebooks/
│   └── heart_disease_analysis.ipynb  # Complete interactive Jupyter notebook
│
├── src/
│   ├── preprocessing.py        # Zero-leakage pipeline & clinical imputation
│   ├── eda_visualizations.py   # Generates 7 publication EDA charts (300 DPI)
│   ├── train_model.py          # MLP training, class weighting & tuning
│   └── evaluate_model.py       # Computes official test metrics & 4 eval plots
│
├── outputs/
│   ├── eda_visualizations/     # 7 PNG figures (Distribution, Heatmap, etc.)
│   ├── evaluation_visualizations/ # 4 PNG figures (Loss, Acc, ROC, CM)
│   ├── heart_disease_mlp_model.keras # Saved trained deep learning model
│   ├── scaler.joblib           # Frozen training StandardScaler
│   ├── evaluation_metrics.json # Exact verified test metrics
│   └── tuning_results.json     # Hyperparameter grid comparison
│
├── app.py                      # Interactive Streamlit Web Application
├── requirements.txt            # Verified compatible Python dependencies
├── README.md                   # Setup guide & reproduction steps
└── report.md                   # Full academic report with IEEE references
```

---

## 📊 Dataset Specifications

* **Dataset:** Framingham Heart Study 10-Year Cardiovascular Disease Risk Dataset
* **Source:** National Heart, Lung, and Blood Institute (NHLBI) & Boston University ([BioLINCC Portal](https://biolincc.nhlbi.nih.gov/studies/framingham/))
* **Dimensions:** 4,240 records, 16 columns (15 clinical input features + 1 binary ground-truth target)
* **Target:** `TenYearCHD` (0 = No CHD in 10-year follow-up, 1 = CHD event diagnosed)
* **Class Ratio:** 3,596 Negative (84.8%) vs. 644 Positive (15.2%)

---

## 🚀 Execution Instructions

### Option 1: Local Terminal (Windows / macOS / Linux)

1. **Clone or extract repository:**
   ```bash
   cd Heart_Disease_Deep_Learning
   ```

2. **Create and activate a virtual environment:**
   - **Windows:**
     ```powershell
     python -m venv venv
     .\venv\Scripts\activate
     ```
   - **macOS / Linux:**
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the pipeline step by step:**
   ```bash
   # Step 1 & 2: Preprocess and generate splits
   python src/preprocessing.py

   # Step 3: Generate 7 publication EDA charts
   python src/eda_visualizations.py

   # Step 4: Train Multilayer Perceptron & tune hyperparameters
   python src/train_model.py

   # Step 5: Evaluate model on unseen test set & generate evaluation plots
   python src/evaluate_model.py
   ```

5. **Launch the interactive Streamlit demonstration:**
   ```bash
   streamlit run app.py
   ```

---

### Option 2: Google Colab Setup (Zero-Install)

1. Open [Google Colab](https://colab.research.google.com).
2. Click **File -> Upload notebook** and select `notebooks/heart_disease_analysis.ipynb`.
3. In the first code cell, execute:
   ```python
   !pip install -q scikit-learn matplotlib seaborn tensorflow
   ```
4. Run all cells sequentially (**Runtime -> Run all**).

---

## 🧠 Deep Learning Architecture & Evaluation

* **Model Type:** Multilayer Perceptron (MLP) Sequential Neural Network
* **Hidden Layers:**
  - Layer 1: 32 units, ReLU activation, Batch Normalization, Dropout (0.10), L2 regularizer
  - Layer 2: 16 units, ReLU activation, Batch Normalization, Dropout (0.10), L2 regularizer
* **Output Layer:** 1 unit, Sigmoid activation
* **Loss Function:** Binary Cross-Entropy with balanced class weighting ($w_0 = 0.590, w_1 = 3.290$)
* **Optimizer:** Adam (learning rate = 0.001)

### Actual Verified Test Performance (N = 636 Unseen Patients)

| Metric | Standard ($\tau = 0.50$) | Clinical Screening ($\tau = 0.35$) |
|---|---|---|
| **ROC-AUC Score** | **0.6788** | **0.6788** |
| **Accuracy** | **69.03%** | 51.10% |
| **Recall (Sensitivity)** | **54.17%** | **79.17%** |
| **Precision** | 25.37% | 20.71% |
| **F1-Score** | 0.3455 | 0.3283 |
| **True Negatives (TN)** | 387 | 249 |
| **False Positives (FP)** | 153 | 291 |
| **False Negatives (FN)** | 44 | **20** |
| **True Positives (TP)** | 52 | **76** |

---

## 🛠 Troubleshooting & Common Issues

1. **`ModuleNotFoundError: No module named 'tensorflow'`**
   - Run `pip install tensorflow-cpu` or `pip install tensorflow`.
2. **`FileNotFoundError: framingham.csv not found`**
   - Ensure `framingham.csv` is placed in `data/framingham.csv` or the project root.
3. **`UserWarning: FixedFormatter should only be used together with FixedLocator`**
   - Benign Matplotlib formatting notice; figures are generated and saved normally.

---

## 📜 Disclaimer
This software is an educational prototype and is **not intended for clinical diagnostic use**.
