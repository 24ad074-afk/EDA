"""
train_model.py
==============
Step 4: Deep Learning Model Architecture, Hyperparameter Tuning & Training
Project: Heart Disease Prediction Using Deep Learning with EDA & Visualization
Framework: TensorFlow 2.x & Keras

This script:
1. Loads the preprocessed splits (X_train, y_train, X_val, y_val, X_test, y_test)
2. Explains the theoretical justification for Multilayer Perceptron (MLP) on tabular clinical data
3. Explores a hyperparameter tuning grid across 3 distinct MLP configurations:
   - Config A (Compact): [32 -> 16], Dropout 0.1, LR 0.001
   - Config B (Standard Deep): [64 -> 32], Dropout 0.2, LR 0.001
   - Config C (Regularized Deep): [64 -> 32 -> 16], Dropout 0.3, LR 0.0005
4. Implements EarlyStopping to curb overfitting and restore best validation weights
5. Uses Class Weights to tackle the 85:15 epidemiological class imbalance
6. Selects the champion model based strictly on validation ROC-AUC
7. Persists the champion model and training history for evaluation
"""

import os
import json
import joblib
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers, callbacks

# Set deterministic random seeds
RANDOM_SEED = 42
tf.random.set_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

def build_mlp_model(input_dim: int, hidden_units: list, dropout_rate: float, learning_rate: float, l2_reg: float = 1e-4):
    """
    Constructs a Keras Sequential Multilayer Perceptron (MLP).
    
    Why MLP for Tabular Clinical Data:
    Unlike convolutional networks (designed for spatial pixel grids) or transformers
    (designed for sequential text tokens), MLPs with dense connections are ideal for
    tabular clinical attributes where each input feature has a distinct semantic identity.
    Dense layers learn non-linear feature interactions (e.g., compounding risk of age + sysBP + smoking).
    """
    model = keras.Sequential()
    
    # Input Layer + First Hidden Layer
    model.add(layers.Input(shape=(input_dim,)))
    
    for i, units in enumerate(hidden_units):
        model.add(layers.Dense(
            units,
            activation='relu',
            kernel_regularizer=regularizers.l2(l2_reg),
            name=f"hidden_dense_{i+1}_{units}"
        ))
        model.add(layers.BatchNormalization(name=f"batch_norm_{i+1}"))
        if dropout_rate > 0.0:
            model.add(layers.Dropout(dropout_rate, name=f"dropout_{i+1}_{int(dropout_rate*100)}"))

    # Output Layer: Single unit with Sigmoid activation for binary risk probability [0.0, 1.0]
    model.add(layers.Dense(1, activation='sigmoid', name="output_sigmoid"))

    # Compile with Adam optimizer and Binary Cross-Entropy loss
    optimizer = keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='binary_crossentropy',
        metrics=[
            'accuracy',
            keras.metrics.Precision(name='precision'),
            keras.metrics.Recall(name='recall'),
            keras.metrics.AUC(name='auc')
        ]
    )
    return model

def compute_class_weights(y_train):
    """
    Calculates balanced class weights:
    weight = N / (2 * count)
    Prevents the neural network from degenerating into a trivial majority-class predictor.
    """
    neg_count = (y_train == 0).sum()
    pos_count = (y_train == 1).sum()
    total = len(y_train)
    weight_0 = total / (2.0 * neg_count)
    weight_1 = total / (2.0 * pos_count)
    print(f"Calculated Class Weights -> Class 0 (No CHD): {weight_0:.3f}, Class 1 (CHD): {weight_1:.3f}")
    return {0: weight_0, 1: weight_1}

def train_and_tune(processed_data_path: str, output_dir: str = "Heart_Disease_Deep_Learning/outputs"):
    os.makedirs(output_dir, exist_ok=True)
    
    data = joblib.load(processed_data_path)
    X_train = np.array(data["X_train"], dtype=np.float32)
    y_train = np.array(data["y_train"], dtype=np.float32)
    X_val = np.array(data["X_val"], dtype=np.float32)
    y_val = np.array(data["y_val"], dtype=np.float32)
    
    input_dim = X_train.shape[1]
    print("=" * 70)
    print(f"DEEP LEARNING MODEL INITIALIZATION (Input Features = {input_dim})")
    print("=" * 70)

    class_weights = compute_class_weights(y_train)

    # Candidate Configurations for Hyperparameter Tuning
    configurations = [
        {
            "name": "Config_A_Compact",
            "hidden_units": [32, 16],
            "dropout": 0.10,
            "lr": 0.001,
            "batch_size": 32,
            "epochs": 60
        },
        {
            "name": "Config_B_Standard_Deep",
            "hidden_units": [64, 32],
            "dropout": 0.20,
            "lr": 0.001,
            "batch_size": 32,
            "epochs": 60
        },
        {
            "name": "Config_C_Regularized_Deep",
            "hidden_units": [64, 32, 16],
            "dropout": 0.30,
            "lr": 0.0005,
            "batch_size": 32,
            "epochs": 60
        }
    ]

    tuning_results = []
    best_val_auc = -1.0
    best_model = None
    best_history = None
    best_config = None

    for cfg in configurations:
        print("\n" + "-" * 70)
        print(f"Tuning Candidate: {cfg['name']} | Units: {cfg['hidden_units']} | Dropout: {cfg['dropout']} | LR: {cfg['lr']}")
        print("-" * 70)
        
        model = build_mlp_model(
            input_dim=input_dim,
            hidden_units=cfg["hidden_units"],
            dropout_rate=cfg["dropout"],
            learning_rate=cfg["lr"]
        )

        early_stopping = callbacks.EarlyStopping(
            monitor='val_auc',
            mode='max',
            patience=15,
            restore_best_weights=True,
            verbose=0
        )

        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=cfg["epochs"],
            batch_size=cfg["batch_size"],
            class_weight=class_weights,
            callbacks=[early_stopping],
            verbose=0
        )

        val_eval = model.evaluate(X_val, y_val, verbose=0)
        val_loss, val_acc, val_prec, val_rec, val_auc = val_eval

        result_entry = {
            "config_name": cfg["name"],
            "hidden_units": str(cfg["hidden_units"]),
            "dropout": cfg["dropout"],
            "learning_rate": cfg["lr"],
            "stopped_epoch": len(history.history['loss']),
            "val_loss": round(float(val_loss), 4),
            "val_accuracy": round(float(val_acc), 4),
            "val_precision": round(float(val_prec), 4),
            "val_recall": round(float(val_rec), 4),
            "val_auc": round(float(val_auc), 4)
        }
        tuning_results.append(result_entry)
        print(f"Results -> Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f} | Val Recall: {val_rec:.4f} | Val ROC-AUC: {val_auc:.4f}")

        if val_auc > best_val_auc:
            best_val_auc = val_auc
            best_model = model
            best_history = history.history
            best_config = cfg

    print("\n" + "=" * 70)
    print(f"CHAMPION MODEL SELECTED: {best_config['name']} with Validation ROC-AUC: {best_val_auc:.4f}")
    print("=" * 70)
    best_model.summary()

    # Save champion model in .keras format and weights
    keras_model_path = os.path.join(output_dir, "heart_disease_mlp_model.keras")
    best_model.save(keras_model_path)
    print(f"Persisted trained Keras model to {keras_model_path}")

    # Export architecture weights as JSON for standalone client-side JavaScript / Python execution
    weights_list = []
    for layer in best_model.layers:
        layer_weights = layer.get_weights()
        if layer_weights:
            weights_list.append({
                "name": layer.name,
                "weights": [w.tolist() for w in layer_weights]
            })
    with open(os.path.join(output_dir, "model_weights.json"), "w") as f:
        json.dump(weights_list, f)

    # Save tuning summary
    with open(os.path.join(output_dir, "tuning_results.json"), "w") as f:
        json.dump(tuning_results, f, indent=2)

    # Save training history
    serializable_history = {k: [float(v) for v in vals] for k, vals in best_history.items()}
    with open(os.path.join(output_dir, "training_history.json"), "w") as f:
        json.dump(serializable_history, f, indent=2)

    return best_model, best_config, serializable_history

if __name__ == "__main__":
    processed_path = "Heart_Disease_Deep_Learning/outputs/processed_data.joblib"
    train_and_tune(processed_path)
