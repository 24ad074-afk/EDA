"""
evaluate_model.py
=================
Step 5: Rigorous Model Evaluation, Metric Computation, and Visualization
Project: Heart Disease Prediction Using Deep Learning with EDA & Visualization
Framework: TensorFlow 2.x & Scikit-Learn

This module:
1. Evaluates the champion Keras MLP model strictly on the unseen Test set (X_test, y_test)
2. Computes the official academic metric suite:
   - Accuracy
   - Precision
   - Recall (Sensitivity)
   - Specificity
   - F1-Score
   - ROC-AUC Score
   - Confusion Matrix (TN, FP, FN, TP)
3. Evaluates decision threshold trade-offs (Standard 0.50 vs Clinical Screening 0.35)
4. Generates the 4 required evaluation visualizations:
   - Chart 1: Training and Validation Loss vs Epoch
   - Chart 2: Training and Validation Accuracy vs Epoch
   - Chart 3: Confusion Matrix Heatmap (with annotations)
   - Chart 4: ROC Curve with AUC Score
5. Persists evaluation metrics to JSON for report and web dashboard display
"""

import os
import json
import joblib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix
)
import tensorflow as tf

PRIMARY_COLOR = '#e11d48'
SECONDARY_COLOR = '#0284c7'
NEUTRAL_COLOR = '#334155'

def evaluate_and_plot(model_path: str, data_path: str, history_path: str, output_dirs: list):
    for d in output_dirs:
        os.makedirs(d, exist_ok=True)

    # Load artifacts
    model = tf.keras.models.load_model(model_path)
    data = joblib.load(data_path)
    with open(history_path, "r") as f:
        history = json.load(f)

    X_test = np.array(data["X_test"], dtype=np.float32)
    y_test = np.array(data["y_test"], dtype=np.int32)

    # Generate probabilities on test set
    y_pred_probs = model.predict(X_test, verbose=0).flatten()

    # Metrics at standard threshold (0.50)
    threshold_std = 0.50
    y_pred_std = (y_pred_probs >= threshold_std).astype(int)
    cm_std = confusion_matrix(y_test, y_pred_std)
    tn_s, fp_s, fn_s, tp_s = cm_std.ravel()

    acc_std = accuracy_score(y_test, y_pred_std)
    prec_std = precision_score(y_test, y_pred_std, zero_division=0)
    rec_std = recall_score(y_test, y_pred_std)
    f1_std = f1_score(y_test, y_pred_std)
    auc_score = roc_auc_score(y_test, y_pred_probs)

    # Metrics at clinical screening threshold (0.35) - prioritizes recall to reduce fatal false negatives
    threshold_clin = 0.35
    y_pred_clin = (y_pred_probs >= threshold_clin).astype(int)
    cm_clin = confusion_matrix(y_test, y_pred_clin)
    tn_c, fp_c, fn_c, tp_c = cm_clin.ravel()
    acc_clin = accuracy_score(y_test, y_pred_clin)
    prec_clin = precision_score(y_test, y_pred_clin, zero_division=0)
    rec_clin = recall_score(y_test, y_pred_clin)
    f1_clin = f1_score(y_test, y_pred_clin)

    print("=" * 70)
    print("STEP 5: UNBIASED TEST EVALUATION RESULTS")
    print("=" * 70)
    print(f"Total Test Samples: {len(y_test)} (Class 0: {(y_test==0).sum()}, Class 1: {(y_test==1).sum()})")
    print(f"\n--- Standard Threshold (0.50) ---")
    print(f"Accuracy:        {acc_std:.4f} ({acc_std*100:.2f}%)")
    print(f"Precision:       {prec_std:.4f} ({prec_std*100:.2f}%)")
    print(f"Recall:          {rec_std:.4f} ({rec_std*100:.2f}%)")
    print(f"F1-Score:        {f1_std:.4f}")
    print(f"ROC-AUC Score:   {auc_score:.4f}")
    print(f"Confusion Matrix: TN={tn_s}, FP={fp_s}, FN={fn_s}, TP={tp_s}")

    print(f"\n--- Clinical Screening Threshold (0.35) ---")
    print(f"Accuracy:        {acc_clin:.4f} ({acc_clin*100:.2f}%)")
    print(f"Precision:       {prec_clin:.4f}")
    print(f"Recall:          {rec_clin:.4f} (Increased sensitivity for medical screening)")
    print(f"F1-Score:        {f1_clin:.4f}")
    print(f"Confusion Matrix: TN={tn_c}, FP={fp_c}, FN={fn_c}, TP={tp_c}")

    # -------------------------------------------------------------
    # Visualization 1: Training and Validation Loss vs Epoch
    # -------------------------------------------------------------
    epochs = range(1, len(history['loss']) + 1)
    fig, ax = plt.subplots(figsize=(7.5, 5), dpi=300)
    ax.plot(epochs, history['loss'], color=SECONDARY_COLOR, linewidth=2.2, label='Training Loss (Binary Cross-Entropy)')
    ax.plot(epochs, history['val_loss'], color=PRIMARY_COLOR, linewidth=2.2, linestyle='--', label='Validation Loss')
    ax.set_title("1. Training and Validation Loss vs. Epoch", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Epoch", fontsize=11, fontweight='bold')
    ax.set_ylabel("Binary Cross-Entropy Loss", fontsize=11, fontweight='bold')
    ax.legend(frameon=True, fontsize=10)
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "01_loss_vs_epoch.png"))
    plt.close()
    print("Saved: 01_loss_vs_epoch.png")

    # -------------------------------------------------------------
    # Visualization 2: Training and Validation Accuracy vs Epoch
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 5), dpi=300)
    ax.plot(epochs, [a * 100 for a in history['accuracy']], color=SECONDARY_COLOR, linewidth=2.2, label='Training Accuracy (%)')
    ax.plot(epochs, [a * 100 for a in history['val_accuracy']], color=PRIMARY_COLOR, linewidth=2.2, linestyle='--', label='Validation Accuracy (%)')
    ax.set_title("2. Training and Validation Accuracy vs. Epoch", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Epoch", fontsize=11, fontweight='bold')
    ax.set_ylabel("Accuracy (%)", fontsize=11, fontweight='bold')
    ax.legend(frameon=True, fontsize=10)
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "02_accuracy_vs_epoch.png"))
    plt.close()
    print("Saved: 02_accuracy_vs_epoch.png")

    # -------------------------------------------------------------
    # Visualization 3: Confusion Matrix Heatmap
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(6.5, 5.5), dpi=300)
    group_names = ['True Neg (TN)', 'False Pos (FP)', 'False Neg (FN)', 'True Pos (TP)']
    group_counts = [f"{value:,}" for value in cm_std.flatten()]
    group_percentages = [f"{value:.1%}" for value in cm_std.flatten() / np.sum(cm_std)]
    labels = [f"{v1}\n{v2}\n({v3})" for v1, v2, v3 in zip(group_names, group_counts, group_percentages)]
    labels = np.asarray(labels).reshape(2, 2)

    sns.heatmap(cm_std, annot=labels, fmt='', cmap='Blues', cbar=False, ax=ax,
                annot_kws={"size": 11, "fontweight": 'bold'})
    ax.set_title(f"3. Test Confusion Matrix (Threshold = {threshold_std})", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Predicted Clinical Label", fontsize=11, fontweight='bold')
    ax.set_ylabel("Actual Ground Truth Label", fontsize=11, fontweight='bold')
    ax.set_xticklabels(['No CHD (0)', 'CHD (1)'], fontsize=10)
    ax.set_yticklabels(['No CHD (0)', 'CHD (1)'], fontsize=10)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "03_confusion_matrix.png"))
    plt.close()
    print("Saved: 03_confusion_matrix.png")

    # -------------------------------------------------------------
    # Visualization 4: ROC Curve with AUC Score
    # -------------------------------------------------------------
    fpr, tpr, _ = roc_curve(y_test, y_pred_probs)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=300)
    ax.plot(fpr, tpr, color=PRIMARY_COLOR, linewidth=2.5, label=f'MLP Neural Net (AUC = {auc_score:.3f})')
    ax.plot([0, 1], [0, 1], color='#94a3b8', linestyle=':', linewidth=1.8, label='Random Chance Baseline (AUC = 0.500)')
    ax.fill_between(fpr, tpr, alpha=0.15, color=PRIMARY_COLOR)
    ax.set_title("4. Receiver Operating Characteristic (ROC) Curve", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("False Positive Rate (1 - Specificity)", fontsize=11, fontweight='bold')
    ax.set_ylabel("True Positive Rate (Sensitivity / Recall)", fontsize=11, fontweight='bold')
    ax.legend(loc='lower right', frameon=True, fontsize=10)
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "04_roc_curve.png"))
    plt.close()
    print("Saved: 04_roc_curve.png")

    # Save metrics JSON
    metrics = {
        "test_samples": len(y_test),
        "test_negatives": int(tn_s + fp_s),
        "test_positives": int(fn_s + tp_s),
        "threshold_default": {
            "threshold": threshold_std,
            "accuracy": round(float(acc_std), 4),
            "precision": round(float(prec_std), 4),
            "recall": round(float(rec_std), 4),
            "f1_score": round(float(f1_std), 4),
            "roc_auc": round(float(auc_score), 4),
            "confusion_matrix": {
                "tn": int(tn_s), "fp": int(fp_s),
                "fn": int(fn_s), "tp": int(tp_s)
            }
        },
        "threshold_clinical_screening": {
            "threshold": threshold_clin,
            "accuracy": round(float(acc_clin), 4),
            "precision": round(float(prec_clin), 4),
            "recall": round(float(rec_clin), 4),
            "f1_score": round(float(f1_clin), 4),
            "confusion_matrix": {
                "tn": int(tn_c), "fp": int(fp_c),
                "fn": int(fn_c), "tp": int(tp_c)
            }
        },
        "roc_curve_points": {
            "fpr": [round(float(x), 4) for x in fpr[::max(1, len(fpr)//50)]],
            "tpr": [round(float(y), 4) for y in tpr[::max(1, len(tpr)//50)]]
        }
    }

    with open("Heart_Disease_Deep_Learning/outputs/evaluation_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    with open("public/outputs/evaluation_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print("All Model Evaluation Figures & Metrics Successfully Saved!")
    return metrics

if __name__ == "__main__":
    evaluate_and_plot(
        model_path="Heart_Disease_Deep_Learning/outputs/heart_disease_mlp_model.keras",
        data_path="Heart_Disease_Deep_Learning/outputs/processed_data.joblib",
        history_path="Heart_Disease_Deep_Learning/outputs/training_history.json",
        output_dirs=[
            "Heart_Disease_Deep_Learning/outputs/evaluation_visualizations",
            "public/outputs/evaluation_visualizations"
        ]
    )
