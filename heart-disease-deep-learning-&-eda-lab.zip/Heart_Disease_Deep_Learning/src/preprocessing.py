"""
preprocessing.py
================
Step 2: Data Understanding, Cleaning, and Preprocessing Pipeline
Project: Heart Disease Prediction Using Deep Learning with EDA & Visualization
Dataset: Framingham Heart Study (4,240 records, 15 input features + 1 target)

This module handles:
1. Loading the dataset and performing initial health checks (head, tail, shape, dtypes)
2. Descriptive statistical profiling
3. Missing value analysis and clinical-aware imputation
4. Duplicate detection
5. Outlier detection using IQR with clinical safety preservation
6. Stratified Train / Validation / Test splitting (70% / 15% / 15%)
7. Zero-leakage feature scaling (StandardScaler fit strictly on training set)
"""

import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

def load_and_inspect_data(csv_path: str):
    """
    Loads the dataset and prints summary diagnostics.
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Dataset not found at {csv_path}. Please place framingham.csv in the data directory.")
    
    df = pd.read_csv(csv_path)
    print("=" * 70)
    print("1. DATASET OVERVIEW & STRUCTURAL INTEGRITY")
    print("=" * 70)
    print(f"Total Rows (Patients): {df.shape[0]}")
    print(f"Total Columns: {df.shape[1]} (15 Feature Attributes + 1 Binary Target)")
    print("\nFirst 5 Rows:")
    print(df.head(5))
    print("\nLast 5 Rows:")
    print(df.tail(5))
    print("\nColumn Data Types:")
    print(df.dtypes)
    print("\nSummary Descriptive Statistics:")
    print(df.describe().T)
    return df

def analyze_missing_values(df: pd.DataFrame):
    """
    Computes missing value count and percentage per column.
    """
    print("\n" + "=" * 70)
    print("2. MISSING VALUES DIAGNOSIS")
    print("=" * 70)
    missing = df.isnull().sum()
    missing_pct = (missing / len(df)) * 100
    missing_df = pd.DataFrame({"Missing Count": missing, "Percentage (%)": missing_pct})
    missing_df = missing_df[missing_df["Missing Count"] > 0].sort_values(by="Missing Count", ascending=False)
    print(missing_df)
    return missing_df

def detect_outliers_iqr(df: pd.DataFrame, numerical_cols: list):
    """
    Computes IQR thresholds and outlier counts for numerical columns.
    Explains the clinical strategy for retaining valid medical observations.
    """
    print("\n" + "=" * 70)
    print("3. OUTLIER DETECTION (IQR METHOD) & CLINICAL RATIONALE")
    print("=" * 70)
    outlier_summary = {}
    for col in numerical_cols:
        series = df[col].dropna()
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers = series[(series < lower_bound) | (series > upper_bound)]
        outlier_summary[col] = {
            "Q1": round(q1, 2),
            "Q3": round(q3, 2),
            "IQR": round(iqr, 2),
            "Lower Bound": round(lower_bound, 2),
            "Upper Bound": round(upper_bound, 2),
            "Outlier Count": len(outliers),
            "Outlier %": round(len(outliers) / len(series) * 100, 2)
        }
    summary_df = pd.DataFrame(outlier_summary).T
    print(summary_df)
    print("\nClinical Outlier Strategy Explanation:")
    print("In cardiovascular epidemiology, biological markers like systolic BP > 180 mmHg (hypertensive crisis)")
    print("or fasting glucose > 200 mg/dL (severe diabetes) are NOT data errors. They are critical clinical")
    print("signals directly correlated with heart disease. Therefore, rows are NOT arbitrarily deleted.")
    print("Standardization and neural network gradient clipping ensure stable convergence without signal loss.")
    return summary_df

def preprocess_and_split(csv_path: str, output_dir: str = "Heart_Disease_Deep_Learning/outputs"):
    """
    Full reproducible preprocessing pipeline with strict leakage prevention.
    """
    df = load_and_inspect_data(csv_path)
    analyze_missing_values(df)

    # 1. Duplicate check
    duplicates = df.duplicated().sum()
    print(f"\nDuplicate records detected: {duplicates}")
    if duplicates > 0:
        df = df.drop_duplicates().reset_index(drop=True)
        print("Duplicates successfully removed.")

    # 2. Clinical-aware Missing Value Imputation
    # A. cigsPerDay: If non-smoker, cigsPerDay must be 0; if smoker, impute with smoker median
    if df['cigsPerDay'].isnull().sum() > 0:
        smoker_median = df[df['currentSmoker'] == 1]['cigsPerDay'].median()
        df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 0), 'cigsPerDay'] = 0
        df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 1), 'cigsPerDay'] = smoker_median

    # B. BPMeds: Binary medication flag -> mode imputation
    bpmeds_mode = df['BPMeds'].mode()[0]
    df['BPMeds'] = df['BPMeds'].fillna(bpmeds_mode)

    # C. Education: Categorical/ordinal (1, 2, 3, 4) -> mode imputation
    edu_mode = df['education'].mode()[0]
    df['education'] = df['education'].fillna(edu_mode)

    # D. Continuous physiological markers (totChol, BMI, heartRate, glucose) -> median imputation
    continuous_impute = ['totChol', 'BMI', 'heartRate', 'glucose']
    for col in continuous_impute:
        median_val = df[col].median()
        df[col] = df[col].fillna(median_val)

    print("\nPost-Imputation Missing Value Verification:")
    print(f"Total remaining nulls: {df.isnull().sum().sum()}")

    # Outlier IQR analysis
    num_cols = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    detect_outliers_iqr(df, num_cols)

    # 3. Feature & Target Separation
    target_col = 'TenYearCHD'
    feature_cols = [c for c in df.columns if c != target_col]
    X = df[feature_cols].copy()
    y = df[target_col].copy()

    print("\n" + "=" * 70)
    print("4. STRATIFIED TRAIN / VALIDATION / TEST SPLIT")
    print("=" * 70)
    print(f"Total Features (N={len(feature_cols)}): {feature_cols}")
    print(f"Target Distribution: Class 0 = {(y==0).sum()} ({(y==0).mean():.1%}), Class 1 = {(y==1).sum()} ({(y==1).mean():.1%})")

    # Split 1: 70% Train, 30% Temp (Val + Test) with stratification
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, random_state=RANDOM_SEED, stratify=y
    )

    # Split 2: 50% / 50% of Temp -> 15% Validation, 15% Test
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=RANDOM_SEED, stratify=y_temp
    )

    print(f"Training Set Dimensions:   X_train: {X_train.shape}, y_train: {y_train.shape} (Positives: {y_train.sum()} / {len(y_train)} = {y_train.mean():.1%})")
    print(f"Validation Set Dimensions: X_val:   {X_val.shape},   y_val:   {y_val.shape}   (Positives: {y_val.sum()} / {len(y_val)} = {y_val.mean():.1%})")
    print(f"Testing Set Dimensions:    X_test:  {X_test.shape},  y_test:  {y_test.shape}  (Positives: {y_test.sum()} / {len(y_test)} = {y_test.mean():.1%})")

    # 4. Zero-Leakage Standardization
    # Fit scaler strictly on X_train numerical features
    scaler = StandardScaler()
    X_train_scaled = X_train.copy()
    X_val_scaled = X_val.copy()
    X_test_scaled = X_test.copy()

    X_train_scaled[num_cols] = scaler.fit_transform(X_train[num_cols])
    X_val_scaled[num_cols] = scaler.transform(X_val[num_cols])
    X_test_scaled[num_cols] = scaler.transform(X_test[num_cols])

    # Save processed splits and scaler for training and evaluation
    os.makedirs(output_dir, exist_ok=True)
    joblib.dump(scaler, os.path.join(output_dir, "scaler.joblib"))

    processed_data = {
        "X_train": X_train_scaled,
        "y_train": y_train,
        "X_val": X_val_scaled,
        "y_val": y_val,
        "X_test": X_test_scaled,
        "y_test": y_test,
        "raw_df": df,
        "feature_cols": feature_cols,
        "num_cols": num_cols
    }
    joblib.dump(processed_data, os.path.join(output_dir, "processed_data.joblib"))
    print(f"\nArtifacts successfully persisted to {output_dir}/")
    return processed_data

if __name__ == "__main__":
    csv_file = "Heart_Disease_Deep_Learning/data/framingham.csv"
    if not os.path.exists(csv_file):
        csv_file = "framingham.csv"
    preprocess_and_split(csv_file)
