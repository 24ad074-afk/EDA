"""
eda_visualizations.py
=====================
Step 3: Exploratory Data Analysis and High-Resolution Visualization Suite
Project: Heart Disease Prediction Using Deep Learning with EDA & Visualization
Dataset: Framingham Heart Study

This module generates the 7 essential academic exploratory visualizations:
1. Target Class Distribution (Imbalance analysis)
2. Age Distribution by Heart Disease Status (KDE + Histograms)
3. Pearson Correlation Matrix Heatmap
4. Clinical Boxplots with IQR Outlier Detection
5. Multi-Feature Comparative Density Distributions
6. Scatterplot: Age vs Systolic Blood Pressure by 10-Year CHD Risk
7. Permutation Feature Importance Ranking (using baseline classifier)

All figures are formatted with publication styling (labels, legends, 300 DPI)
and saved to outputs/eda_visualizations/ and public/outputs/eda_visualizations/.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
import json

# Set aesthetic publication defaults
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = 'DejaVu Sans'
plt.rcParams['axes.edgecolor'] = '#cbd5e1'
plt.rcParams['axes.linewidth'] = 0.8

PRIMARY_COLOR = '#e11d48'   # Crimson / Heart Red
SECONDARY_COLOR = '#0284c7' # Ocean Blue
ACCENT_COLOR = '#10b981'    # Emerald

def generate_all_eda(csv_path: str, output_dirs: list):
    df = pd.read_csv(csv_path)

    # Impute for clean visualizations
    if df['cigsPerDay'].isnull().sum() > 0:
        smoker_median = df[df['currentSmoker'] == 1]['cigsPerDay'].median()
        df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 0), 'cigsPerDay'] = 0
        df.loc[(df['cigsPerDay'].isnull()) & (df['currentSmoker'] == 1), 'cigsPerDay'] = smoker_median
    df['BPMeds'] = df['BPMeds'].fillna(df['BPMeds'].mode()[0])
    df['education'] = df['education'].fillna(df['education'].mode()[0])
    for col in ['totChol', 'BMI', 'heartRate', 'glucose']:
        df[col] = df[col].fillna(df[col].median())

    for out_dir in output_dirs:
        os.makedirs(out_dir, exist_ok=True)

    print("Generating 7 Core EDA Visualizations...")

    # -------------------------------------------------------------
    # 1. Target Class Distribution Chart
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)
    counts = df['TenYearCHD'].value_counts().sort_index()
    percentages = (counts / len(df)) * 100
    bars = ax.bar(['No CHD (0)', 'CHD Positive (1)'], counts, color=[SECONDARY_COLOR, PRIMARY_COLOR], width=0.55, edgecolor='#334155', linewidth=1.2)
    
    for bar, count, pct in zip(bars, counts, percentages):
        yval = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, yval + 50, f"{count:,}\n({pct:.1f}%)", ha='center', va='bottom', fontsize=11, fontweight='bold', color='#1e293b')

    ax.set_title("1. Target Class Distribution: 10-Year CHD Risk", fontsize=13, fontweight='bold', pad=15)
    ax.set_ylabel("Patient Count", fontsize=11, fontweight='bold')
    ax.set_ylim(0, max(counts) * 1.18)
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "01_target_distribution.png"))
    plt.close()
    print("Saved: 01_target_distribution.png")

    # -------------------------------------------------------------
    # 2. Age Distribution Histogram & KDE
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5), dpi=300)
    sns.histplot(data=df, x='age', hue='TenYearCHD', palette=[SECONDARY_COLOR, PRIMARY_COLOR],
                 bins=25, kde=True, multiple='stack', edgecolor='white', linewidth=0.8, ax=ax)
    ax.set_title("2. Age Distribution Stratified by 10-Year CHD Outcome", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Patient Age (Years)", fontsize=11, fontweight='bold')
    ax.set_ylabel("Patient Count", fontsize=11, fontweight='bold')
    legend = ax.get_legend()
    if legend:
        legend.set_title("Outcome")
        legend.get_texts()[0].set_text("No CHD (0)")
        legend.get_texts()[1].set_text("CHD (1)")
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "02_age_distribution.png"))
    plt.close()
    print("Saved: 02_age_distribution.png")

    # -------------------------------------------------------------
    # 3. Correlation Heatmap
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(11, 9), dpi=300)
    corr = df.corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    cmap = sns.diverging_palette(220, 10, as_cmap=True)
    sns.heatmap(corr, mask=mask, cmap=cmap, vmin=-0.4, vmax=0.8, annot=True, fmt=".2f",
                square=True, linewidths=0.6, cbar_kws={"shrink": .8, "label": "Pearson Correlation (r)"}, ax=ax,
                annot_kws={"size": 8})
    ax.set_title("3. Pearson Correlation Heatmap Among Features and Outcome", fontsize=13, fontweight='bold', pad=15)
    plt.xticks(rotation=45, ha='right', fontsize=9)
    plt.yticks(rotation=0, fontsize=9)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "03_correlation_heatmap.png"))
    plt.close()
    print("Saved: 03_correlation_heatmap.png")

    # -------------------------------------------------------------
    # 4. Boxplots for Clinical Outlier Detection
    # -------------------------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=(10, 8), dpi=300)
    key_features = [('sysBP', 'Systolic Blood Pressure (mmHg)'),
                    ('totChol', 'Total Serum Cholesterol (mg/dL)'),
                    ('glucose', 'Fasting Blood Glucose (mg/dL)'),
                    ('BMI', 'Body Mass Index (kg/m²)')]
    
    for ax, (feat, label) in zip(axes.flatten(), key_features):
        sns.boxplot(x='TenYearCHD', y=feat, data=df, palette=[SECONDARY_COLOR, PRIMARY_COLOR], width=0.45, ax=ax, fliersize=3)
        ax.set_xticklabels(['No CHD (0)', 'CHD (1)'], fontsize=10, fontweight='bold')
        ax.set_title(label, fontsize=11, fontweight='bold')
        ax.set_xlabel("")
        ax.set_ylabel("Measured Value", fontsize=10)
        ax.grid(axis='y', linestyle='--', alpha=0.5)

    fig.suptitle("4. Clinical Outlier Inspection Across Target Classes (IQR Boxplots)", fontsize=13, fontweight='bold', y=1.00)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "04_outlier_boxplots.png"))
    plt.close()
    print("Saved: 04_outlier_boxplots.png")

    # -------------------------------------------------------------
    # 5. Feature-wise Distribution Plots (KDE Overlay)
    # -------------------------------------------------------------
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), dpi=300)
    dist_features = [('sysBP', 'Systolic BP (mmHg)'),
                     ('totChol', 'Total Cholesterol (mg/dL)'),
                     ('glucose', 'Fasting Glucose (mg/dL)')]

    for ax, (feat, label) in zip(axes, dist_features):
        sns.kdeplot(data=df[df['TenYearCHD'] == 0], x=feat, fill=True, color=SECONDARY_COLOR, label='No CHD (0)', alpha=0.4, ax=ax)
        sns.kdeplot(data=df[df['TenYearCHD'] == 1], x=feat, fill=True, color=PRIMARY_COLOR, label='CHD (1)', alpha=0.4, ax=ax)
        ax.set_title(f"{label} Density", fontsize=11, fontweight='bold')
        ax.set_xlabel(label, fontsize=10)
        ax.set_ylabel("Kernel Density", fontsize=10)
        ax.legend(frameon=True, fontsize=9)
        ax.grid(True, linestyle='--', alpha=0.5)

    fig.suptitle("5. Feature-Wise Continuous Kernel Density Distributions", fontsize=13, fontweight='bold', y=1.02)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "05_feature_distributions.png"))
    plt.close()
    print("Saved: 05_feature_distributions.png")

    # -------------------------------------------------------------
    # 6. Scatterplot: Age vs Systolic Blood Pressure
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 6), dpi=300)
    sns.scatterplot(
        data=df, x='age', y='sysBP', hue='TenYearCHD',
        palette=[SECONDARY_COLOR, PRIMARY_COLOR], alpha=0.6, s=35, edgecolor='none', ax=ax
    )
    # Highlight clinical hypertension line
    ax.axhline(140, color='#eab308', linestyle='--', linewidth=1.5, label='Stage 2 Hypertension (140 mmHg)')
    ax.set_title("6. Relationship Between Patient Age, Systolic BP, and 10-Year CHD", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Patient Age (Years)", fontsize=11, fontweight='bold')
    ax.set_ylabel("Systolic Blood Pressure (mmHg)", fontsize=11, fontweight='bold')
    legend = ax.get_legend()
    if legend:
        legend.get_texts()[0].set_text("No CHD (0)")
        legend.get_texts()[1].set_text("CHD (1)")
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "06_age_vs_sysbp_scatterplot.png"))
    plt.close()
    print("Saved: 06_age_vs_sysbp_scatterplot.png")

    # -------------------------------------------------------------
    # 7. Feature Importance Ranking (Permutation Importance)
    # -------------------------------------------------------------
    X = df.drop(columns=['TenYearCHD'])
    y = df['TenYearCHD']
    rf = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=6)
    rf.fit(X, y)
    result = permutation_importance(rf, X, y, n_repeats=10, random_state=42, scoring='roc_auc')
    sorted_idx = result.importances_mean.argsort()

    fig, ax = plt.subplots(figsize=(9, 6), dpi=300)
    bar_colors = [PRIMARY_COLOR if i >= len(sorted_idx) - 5 else SECONDARY_COLOR for i in range(len(sorted_idx))]
    ax.barh(X.columns[sorted_idx], result.importances_mean[sorted_idx],
            xerr=result.importances_std[sorted_idx], color=bar_colors, edgecolor='#334155', linewidth=0.8, alpha=0.9)
    ax.set_title("7. Feature Importance via Permutation ROC-AUC Metric", fontsize=13, fontweight='bold', pad=15)
    ax.set_xlabel("Mean Decrease in ROC-AUC Score", fontsize=11, fontweight='bold')
    ax.grid(axis='x', linestyle='--', alpha=0.6)
    plt.tight_layout()
    for d in output_dirs:
        plt.savefig(os.path.join(d, "07_feature_importance.png"))
    plt.close()
    print("Saved: 07_feature_importance.png")

    # Save summary metadata for the web dashboard
    eda_summary = {
        "dataset_name": "Framingham Heart Study",
        "total_records": len(df),
        "total_features": len(X.columns),
        "class_0_count": int(counts[0]),
        "class_1_count": int(counts[1]),
        "class_0_pct": round(float(percentages[0]), 2),
        "class_1_pct": round(float(percentages[1]), 2),
        "mean_age_no_chd": round(float(df[df['TenYearCHD']==0]['age'].mean()), 1),
        "mean_age_chd": round(float(df[df['TenYearCHD']==1]['age'].mean()), 1),
        "top_features": list(X.columns[sorted_idx[-5:]][::-1])
    }
    with open("Heart_Disease_Deep_Learning/outputs/eda_summary.json", "w") as f:
        json.dump(eda_summary, f, indent=2)
    with open("public/outputs/eda_summary.json", "w") as f:
        json.dump(eda_summary, f, indent=2)

    print("EDA Visualizations & Summary successfully generated!")

if __name__ == "__main__":
    csv_file = "Heart_Disease_Deep_Learning/data/framingham.csv"
    if not os.path.exists(csv_file):
        csv_file = "framingham.csv"
    output_folders = [
        "Heart_Disease_Deep_Learning/outputs/eda_visualizations",
        "public/outputs/eda_visualizations"
    ]
    generate_all_eda(csv_file, output_folders)
